PinkiesUp
=========

An iPad game

Note: To use more than 2 fingers in all your Apps, turn off Multitasking Gestures in your General Settings.