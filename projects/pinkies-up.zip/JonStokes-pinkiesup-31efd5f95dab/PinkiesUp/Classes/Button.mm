//
//  Button.m
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/18/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Button.h"
#import "Global.h"
#import "Library.h"
#import "Triangulate.h"

@interface Button (Private)
// read only variables
@property(nonatomic, readwrite) BOOL isPressed;
@property(nonatomic, readwrite) BOOL isOn;
@end

@implementation Button

//static const float FLASH_LENGTH = .15;

@dynamic isPressed, isOn, isEnabled, color2;
@synthesize canTurnOff, positionInSequence, sequenceWasChecked;

#pragma mark - overridden functions
+ (id)initWithVertices:(NSMutableArray*)vertices {
	return [[[self alloc] initWithVertices:vertices] autorelease];
}

- (id)initWithVertices:(NSMutableArray*)_vertices {
	if (!(self = [super init]))
		return nil;
	
	//CCLOG(@"initializing a button");
	
	self.color2 = ccc4f(CCRANDOM_0_1(), CCRANDOM_0_1(), CCRANDOM_0_1(), 1);
	self.isEnabled = YES;
	self.isOn = NO;
	self.isPressed = NO;
	self.canTurnOff = YES;
	sequenceWasChecked = NO;
	positionInSequence = -1;
	flashAlpha = 1;
	isFlashing = NO;
	
	// convert vertices NSMutableArray to vector<CGPoint>
	//std::vector<CGPoint> verticesVector;
	
	for (int i = 0; i < _vertices.count; i++) {
		CGPoint p = [[_vertices objectAtIndex:i] CGPointValue];
		verticesVector.push_back(ccp(p.x, p.y));
	}
	
	// todo: optimize: only triangulate if needed, else use GL_TRIANGLE_FAN
	
	// todo: create triangulate function, do triangulate crap, takes _vertices returns fv
	
	// triangulate begin -----------------------------------------
	
	// convert vertices container to C++ vector with Vector2d
	Vector2dVector v2v;
	
	for (int i = 0; i < _vertices.count; i++) {
		CGPoint p = verticesVector[i];
		v2v.push_back(Vector2d(p.x, p.y));
	}
	
	// triangulate
	Vector2dVector v2vr;
	Triangulate::Process(v2v,v2vr);
	
	// convert to something more standard
	//std::vector<float> triangleVertices;
	
	for (int i = 0; i < v2vr.size()/3; i++) {
		const Vector2d &p1 = v2vr[i*3+0];
		const Vector2d &p2 = v2vr[i*3+1];
		const Vector2d &p3 = v2vr[i*3+2];
		
		triangleVertices.push_back(p1.GetX());
		triangleVertices.push_back(p1.GetY());
		
		triangleVertices.push_back(p2.GetX());
		triangleVertices.push_back(p2.GetY());
		
		triangleVertices.push_back(p3.GetX());
		triangleVertices.push_back(p3.GetY());
	}
	
	// triangulate end -------------------------------------------
		
	return self;
}

- (void)draw {
	// set blend function
	// source.color * source.alpha + destination.color * (1-source.alpha)
	//glEnable(GL_BLEND); // not needed
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	
	// draw black layer to cover Harold
	glColor4f(0, 0, 0, 1);
	[Library drawTrianglesWithVertices:triangleVertices];
	
	if (isFlashing) {
		// draw white layer
		glColor4f(1, 1, 1, 1);
		[Library drawTrianglesWithVertices:triangleVertices];
	}
	
	// draw colored layer
	glColor4f(color2.r, color2.g, color2.b, color2.a * flashAlpha);
	[Library drawTrianglesWithVertices:triangleVertices];
}

- (void)onEnter {
    [[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:NO];
    [super onEnter];
}

- (void)onExit {
	//CCLOG(@"[Button onExit]");
    [[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
    [super onExit];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event {
//    if (!isEnabled)
//		return NO;
	
    if (isPressed)
		return NO;
	
	CGPoint location = [touch locationInView:[touch view]];
    location = [[CCDirector sharedDirector] convertToGL:location];
	
	if (![Library IsPointInPolygonWithVector:verticesVector :verticesVector.size() :location.x :location.y])
		return NO;
	
	if (!isEnabled) {
		[self flash]; // can flash disabled buttons
		return NO;
	}
	
    self.isPressed = YES;
	
	self.isOn = canTurnOff ? !isOn : YES;
	[self flash];
	
    return YES;
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event {
    if (!isEnabled)
		return;
	
	self.isPressed = NO;
}

- (void)dealloc {
	//CCLOG(@"[Button dealloc]");
    [super dealloc];
}

#pragma mark - public functions
- (void) reset {
	self.isOn = NO;
	self.isPressed = NO;
	sequenceWasChecked = NO;
}

- (void)flash {
	[self unschedule:@selector(updateFlash)];
	[self unschedule:@selector(updateFlash2)];
	isFlashing = YES;
	flashAlpha = 1;
	[self schedule:@selector(updateFlash)];
}

#pragma mark - private functions
- (void) updateFlash {
	flashAlpha -= FLASH_LENGTH;
	if (flashAlpha <= 0) {
		flashAlpha = 0;
		[self unschedule:@selector(updateFlash)];
		[self schedule:@selector(updateFlash2)];
	}
}

- (void) updateFlash2 {
	flashAlpha += FLASH_LENGTH;
	if (flashAlpha >= 1) {
		isFlashing = NO;
		flashAlpha = 1;
		[self unschedule:@selector(updateFlash2)];
	}
}

#pragma mark - public properties
- (BOOL)isEnabled {
	return isEnabled;
}

- (void)setIsEnabled :(BOOL)_isEnabled {
	if ((isEnabled && _isEnabled) || (!isEnabled && !_isEnabled))
		return;
	
	if (_isEnabled) {
		isEnabled = YES;
		//[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:NO];
		self.isOn = NO;
	}
	else {
		isEnabled = NO;
		//[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
		color2.a *= .5;
	}
}

- (ccColor4F) color2 {
	return color2;
}

- (void)setColor2:(ccColor4F)_color2 {
	color2 = ccc4f(_color2.r, _color2.g, _color2.b, color2.a);
}

#pragma mark - readonly properties
- (BOOL)isPressed {
	return isPressed;
}

- (void)setIsPressed :(BOOL)_isPressed {
	if ((isPressed && _isPressed) || (!isPressed && !_isPressed))
		return;
	
	if (_isPressed) {
		isPressed = YES;
		//[self setTexture:pressedTexture];
	}
	else {
		isPressed = NO;
	}
}

- (BOOL)isOn {
	return isOn;
}

- (void)setIsOn :(BOOL)_isOn {
	if(_isOn) {
		isOn = YES;
		color2.a = 1;
	}
	else {
		isOn = NO;
		color2.a = .5;
	}
}

@end