/*
 
 File: Device.m
 Abstract: Represents a phisical device.
 Version: 1.0

 */

#import "Device.h"
#import "NetworkingConstants.h"

#define CONNECTION_TIMEOUT 30

@implementation Device

@synthesize deviceName, peerID;

- (id)initWithSession:(GKSession *)openSession peer:(NSString *)ID {
    if (!(self = [super init]))
		return nil;
	
	session = [openSession retain];
	peerID = [ID copy];
	deviceName = [[session displayNameForPeer:peerID] copy];
	
	return self;
}

- (BOOL)isEqual:(id)object {
	// Basically, compares the peerIDs
	return object && ([object isKindOfClass:[Device class]]) && ([((Device *) object).peerID isEqual:peerID]);
}

- (void)connectAndReplyTo:(id)delegate selector:(SEL)connectionEstablishedConnection errorSelector:(SEL)connectionNotEstablishedConnection {
	// We need to persist this info, because the call to connect is assynchronous.
	delegateToCallAboutConnection = delegate;
	selectorToPerformWhenConnectionWasEstablished = connectionEstablishedConnection;
	selectorToPerformWhenConnectionWasNotEstablished = connectionNotEstablishedConnection;
	
	// The SessionManager will be responsible for sending the notification that will be caught here.
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(triggerConnectionSuccessfull:) name:NOTIFICATION_DEVICE_CONNECTED object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(triggerConnectionFailed:) name:NOTIFICATION_DEVICE_CONNECTION_FAILED object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(triggerConnectionFailed:) name:NOTIFICATION_DEVICE_UNAVAILABLE object:nil];

	[session connectToPeer:peerID withTimeout:CONNECTION_TIMEOUT];
}

- (void)triggerConnectionSuccessfull:(NSNotification *)notification {
	Device *device = [notification.userInfo objectForKey:DEVICE_KEY];
	
	if ([self isEqual:device] && delegateToCallAboutConnection &&
		[delegateToCallAboutConnection respondsToSelector:selectorToPerformWhenConnectionWasEstablished]) {
		
		[delegateToCallAboutConnection performSelector:selectorToPerformWhenConnectionWasEstablished];

		delegateToCallAboutConnection = nil;
		selectorToPerformWhenConnectionWasEstablished = nil;
		selectorToPerformWhenConnectionWasNotEstablished = nil;
	}
}

- (void)triggerConnectionFailed:(NSNotification *)notification {
	Device *device = [notification.userInfo objectForKey:DEVICE_KEY];
	
	if ([self isEqual:device] && delegateToCallAboutConnection &&
		[delegateToCallAboutConnection respondsToSelector:selectorToPerformWhenConnectionWasNotEstablished]) {
		[delegateToCallAboutConnection performSelector:selectorToPerformWhenConnectionWasNotEstablished];

		delegateToCallAboutConnection = nil;
		selectorToPerformWhenConnectionWasEstablished = nil;
		selectorToPerformWhenConnectionWasNotEstablished = nil;
	}
}

- (void)disconnect {
	[session disconnectPeerFromAllPeers:peerID];
}

- (void)cancelConnection {
	[session cancelConnectToPeer:peerID];
}

- (BOOL)isConnected {
	// Checks if this device is in the Sessions Connected List
	NSArray *peers = [session peersWithConnectionState:GKPeerStateConnected];
	
	BOOL found = NO;
	
	for (NSString *p in peers) {
		if ([p isEqual:peerID]) {
			found = YES;
			break;
		}
	}
	
	return found;
}

- (BOOL)sendData:(NSData *)data error:(NSError **)error {
	return [session sendData:data toPeers:[NSArray arrayWithObject:peerID] withDataMode:GKSendDataReliable error:error];
}

//- (BOOL)sendDataToAll:(NSData *)data error:(NSError **)error {
//	return [session sendDataToAllPeers:data withDataMode:GKSendDataReliable error:error];
//}

- (void)dealloc {
	[session release];
	[peerID release];
	[deviceName release];
    [super dealloc];
}

@end