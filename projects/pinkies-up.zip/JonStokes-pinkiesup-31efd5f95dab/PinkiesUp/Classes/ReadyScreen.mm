//
//  ReadyScreen.m
//  PinkiesUp
//
//  Created by Rahil Patel on 4/29/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

// UI flow:
// if single player, show start button disabled, enable once enough players join
// if multiplayer, show ready? button disabled, enable once enough players join, click ready? to lock in ready!
// if server, after the server is ready!, show start button disabled, enable once all clients are ready!

#import "ReadyScreen.h"
#import "Global.h"
#import "GameManager.h"
#import "ButtonGroup.h"
#import "GameScreen.h"
#import "MenuScreen.h"

@implementation ReadyScreen

#pragma mark - public functions
+ (CCScene *)scene {
	CCScene *scene = [CCScene node];
	ReadyScreen *layer = [ReadyScreen node];
	[scene addChild: layer];
	return scene;
}

#pragma mark - overridden functions
- (id)init {
	if(!(self=[super init]))
		return nil;
	
	self.isTouchEnabled = YES;
	readyCount = 0;
	
    [GameManager sharedGameManager].screenSize = [[CCDirector sharedDirector] winSize];
	
	CGSize s = [CCDirector sharedDirector].winSize;
	BOOL isMultiplayer = [[GameManager sharedGameManager] isMultiplayer];
	int deviceSequencePosition = [[GameManager sharedGameManager] deviceSequencePosition];
	
	// add buttons
	NSArray* bottomButtons = [[GameManager sharedGameManager] createButtonsWithIsTop:NO isReadyScreen:YES buttonCount:MAX_BUTTONS deviceSequencePosition:deviceSequencePosition];
	bottomButtonGroup = [ButtonGroup initWithButtons:bottomButtons];
	[self addChild:bottomButtonGroup];
	
	NSArray* topButtons = [[GameManager sharedGameManager] createButtonsWithIsTop:YES isReadyScreen:YES buttonCount:MAX_BUTTONS deviceSequencePosition:deviceSequencePosition];
	topButtonGroup = [ButtonGroup initWithButtons:topButtons];
	[self addChild:topButtonGroup];
	
	// add menu
	CCLabelTTF* startLabel = [CCLabelTTF labelWithString:@"Start" fontName:@"Arial" fontSize:32];
	startButton = [CCMenuItemLabel itemWithLabel:startLabel target:self selector:@selector(startButtonPressed)];
	
	CCLabelTTF* readyLabel = [CCLabelTTF labelWithString:@"Ready?" fontName:@"Arial" fontSize:32];
	readyButton = [CCMenuItemLabel itemWithLabel:readyLabel target:self selector:@selector(readyButtonPressed)];
	
	CCLabelTTF* backLabel = [CCLabelTTF labelWithString:@"Back" fontName:@"Arial" fontSize:32];
	CCMenuItemLabel* backButton = [CCMenuItemLabel itemWithLabel:backLabel target:self selector:@selector(backButtonPressed)];;
	
    CCMenu *menu = [CCMenu menuWithItems:readyButton, startButton, backButton, nil];
    menu.position = ccp(s.width/2, s.height/2);
	[menu alignItemsVertically];
    [self addChild:menu];
	
	[startButton setIsEnabled:NO];
	[readyButton setIsEnabled:NO];
	
	if (isMultiplayer)
		[startButton setVisible:NO];
	else
		[readyButton setVisible:NO];
	
	// add labels
	if (isMultiplayer) {
		deviceSequencePositionLabel = [CCLabelTTF labelWithString:@"-" fontName:@"Arial" fontSize:64];
		deviceSequencePositionLabel.position = ccp(s.width/4, s.height/2);
		[self addChild:deviceSequencePositionLabel];
	}
	
	[self schedule: @selector(update:)];
	
	return self;
}

- (void)onExit {
	CCLOG(@"[ReadyScreen onExit]"); // todo: testing dealloc
}

- (void)dealloc {
	CCLOG(@"[ReadyScreen dealloc]");
	[bottomButtonGroup release]; // todo: temporary fix, forcing dealloc
	[topButtonGroup release];
	[super dealloc];
}

#pragma mark - private functions
- (void)update: (ccTime)dt {
	BOOL isMultiplayer = [[GameManager sharedGameManager] isMultiplayer];
	int deviceSequencePosition = [[GameManager sharedGameManager] deviceSequencePosition];
	
	if (!isMultiplayer) {
		if ([bottomButtonGroup onButtonCount] >= MIN_BUTTONS && [topButtonGroup onButtonCount] >= MIN_BUTTONS)
			[startButton setIsEnabled: YES];
		else
			[startButton setIsEnabled: NO];
		return;
	}
	
	// multiplayer
	[self handleReceivedClientData];
	
	deviceSequencePositionLabel.string = [NSString  stringWithFormat:@"%i", deviceSequencePosition + 2];

	if ([startButton visible]) {
		if (readyCount == [[GameManager sharedGameManager] deviceCount])
			[startButton setIsEnabled:YES];
		else
			[startButton setIsEnabled:NO];
		return;
	}
	
	if ([[[readyButton label] string] isEqualToString:@"Ready!"])
		return;
	
	// else "Ready?"
	// if number of players ready is at least 1v1, show start button
	if ([bottomButtonGroup onButtonCount] >= MIN_BUTTONS && [topButtonGroup onButtonCount] >= MIN_BUTTONS)
		[readyButton setIsEnabled: YES];
	else
		[readyButton setIsEnabled: NO];
}

- (void) startButtonPressed {	
	BOOL isMultiplayer = [[GameManager sharedGameManager] isMultiplayer];
	
	if (!isMultiplayer) {
		[self startGame];
		return;
	}
	
	// multiplayer
	
	// tell all clients to start game
	[[GameManager sharedGameManager] sendData:kStartGameToAllDevices];
	
	// tell server to start game
	//[self startGame]; // GameManager tells it to start game
}

- (void)readyButtonPressed {
	BOOL isServer = [[GameManager sharedGameManager] isServer];
	
	if (isServer)
		// server does not increase ready count
		[startButton setVisible:YES];
	
	if ([[[readyButton label] string] isEqualToString:@"Ready!"]) {
		[[readyButton label] setString:@"Ready?"];
		[topButtonGroup setIsEnabled:YES]; // enabling a button sets it to off
		[bottomButtonGroup setIsEnabled:YES];
		
		if (isServer)
			[startButton setVisible:NO];
		else
			[[GameManager sharedGameManager] sendData:kDecreaseReadyCountToServer];
		
		return;
	}
	
	[[readyButton label] setString:@"Ready!"];
	[topButtonGroup setIsEnabled:NO];
	[bottomButtonGroup setIsEnabled:NO];
	
	if (!isServer)
		[[GameManager sharedGameManager] sendData:kIncreaseReadyCountToServer];
}

- (void)backButtonPressed {
	[[CCTouchDispatcher sharedDispatcher] removeAllDelegates]; // todo: temporary fix
	[[CCDirector sharedDirector] replaceScene:[MenuScreen scene]];
}

- (void)startGame {
	// save number of buttons
	[[GameManager sharedGameManager] setTopButtonCount:[topButtonGroup onButtonCount]];
	[[GameManager sharedGameManager] setBottomButtonCount:[bottomButtonGroup onButtonCount]];
	
	// reset score
	[[GameManager sharedGameManager] setTopTeamScore:0];
	[[GameManager sharedGameManager] setBottomTeamScore:0];
	
	// set lapCount // todo: temp
	if ([[GameManager sharedGameManager] isMultiplayer])
		[[GameManager sharedGameManager] setLapCount:1];
	else
		[[GameManager sharedGameManager] setLapCount:LAPS];
	
	// todo: temporary fix, not sure why it's not cleaning up after replaceScene
	//[[ReadyScreen scene] removeAllChildrenWithCleanup:YES];
	//[self release];
	//[self cleanup];
	[[CCTouchDispatcher sharedDispatcher] removeAllDelegates]; // maybe something to do with the button delegates, http://stackoverflow.com/questions/5236176/dealloc-not-fired-when-replacing-scenes-in-cocos2d , needed to call dealloc
	[[CCDirector sharedDirector] replaceScene:[GameScreen scene]];
}

- (void)handleReceivedClientData {
	// handle game related client networking data here
	
	int data = [[GameManager sharedGameManager] dataReceived];
	
	if (data == kEmpty)
		return;
	
	CCLOG(@"ReadyScreen handleReceivedNetworkData data: %i", data);
	
	switch (data) {	
		case kIncreaseReadyCount:
			readyCount++;
			break;
			
		case kDecreaseReadyCount:
			readyCount--;
			break;
			
		case kStartGame:
			[self startGame];
			break;
			
		case kResetGame:
			[[CCDirector sharedDirector] replaceScene:[MenuScreen scene]]; // todo: temp
			break;
			
		default:
			CCLOG(@"ReadyScreen handleReceivedNetworkData bad client data is bad: %i", data);
			break;
	}
	
	[[GameManager sharedGameManager] setDataReceived:kEmpty];
}

@end

