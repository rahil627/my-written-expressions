//
//  TestScene.m
//  PinkiesUp
//
//  Created by Rahil Patel on 6/4/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "MenuScreen.h"
#import "GameManager.h"
#import "ReadyScreen.h"
#import "NetworkingConstants.h"

@implementation MenuScreen

#pragma mark - public functions
+ (CCScene *)scene {
	CCScene *scene = [CCScene node];
	MenuScreen *layer = [MenuScreen node];
	[scene addChild: layer];
	return scene;
}

#pragma mark - overridden functions
- (id)init {
	if(!(self=[super init]))
		return nil;
	
	// add menu
	CGSize s = [CCDirector sharedDirector].winSize;
	
	CCLabelTTF* startSingleDeviceGameLabel = [CCLabelTTF labelWithString:@"start single device game" fontName:@"Arial" fontSize:32];
    CCMenuItemLabel* startSingleDeviceGameMenuItemLabel = [CCMenuItemLabel itemWithLabel:startSingleDeviceGameLabel target:self selector:@selector(startSingleDeviceGame)];
	
	CCLabelTTF* startServerLabel = [CCLabelTTF labelWithString:@"host game" fontName:@"Arial" fontSize:32];
	CCMenuItemLabel* startServerMenuItemLabel = [CCMenuItemLabel itemWithLabel:startServerLabel target:self selector:@selector(startSessionAsServer)];
	
	CCLabelTTF* startClientLabel = [CCLabelTTF labelWithString:@"join game" fontName:@"Arial" fontSize:32];
	CCMenuItemLabel* startClientMenuItemLabel = [CCMenuItemLabel itemWithLabel:startClientLabel target:self selector:@selector(startSessionAsClient)];
	
	CCLabelTTF* testLabel = [CCLabelTTF labelWithString:@"test" fontName:@"Arial" fontSize:32];
    CCMenuItemLabel* testMenuItemLabel = [CCMenuItemLabel itemWithLabel:testLabel target:self selector:@selector(test)];
	[testLabel setVisible:NO]; // todo: testing
	
    CCMenu *menu = [CCMenu menuWithItems:startSingleDeviceGameMenuItemLabel, startServerMenuItemLabel, startClientMenuItemLabel, testMenuItemLabel, nil];
    menu.position = ccp(s.width/2, s.height/2);
	[menu alignItemsVertically];
    [self addChild:menu];
	
	// add devicesCount label
	devicesCountLabel = [CCLabelTTF labelWithString:@"device count: 0" fontName:@"Arial" fontSize:32];
	devicesCountLabel.position = ccp(s.width/2, 50);
	[self addChild:devicesCountLabel];
	
	// init GameManager (not necessary)
	[GameManager sharedGameManager];
	
	// add notification handlers
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connectionWasSuccessful:) name:NOTIFICATION_THIS_DEVICE_CONNECTED object:nil];
	
	[self schedule: @selector(update:)];
	
	return self;
}

- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	[super dealloc];
}

#pragma mark - private functions
- (void)update: (ccTime)dt {
	int deviceCount = [[GameManager sharedGameManager] deviceCount];
	devicesCountLabel.string = [NSString  stringWithFormat:@"devices: %i", deviceCount];
	//sequenceCountLabel.string = [NSString  stringWithFormat:@"sequence: %i",; // get sequence
}

- (void)test {
	
	// send data
//	[GameManager sharedGameManager].dataToSend = kAddTopAthlete;
//	
//	if ([devicesManager.sortedDevices count] > 0) {
//		Device *device = ((Device *) [devicesManager.sortedDevices objectAtIndex:0]);
//		[[[GameManager sharedGameManager] dataHandler] sendToDevice:device];
//	}
	
	// display client list
//	[[GameManager sharedGameManager] setDataToSend:kAddTopAthlete];
//	
//	for (int i = 0; i < [devicesManager.sortedDevices count]; i++) {
//		Device *device = ((Device *) [devicesManager.sortedDevices objectAtIndex:i]);
//		NSLog(@"index: %i peerID: %@ deviceName: %@", i, device.peerID, device.deviceName);
//	}
}

- (void)startSingleDeviceGame {
	[[GameManager sharedGameManager] endSession];
	[[GameManager sharedGameManager] setIsMultiplayer:NO];
	[self goToReadyScreen];
}

- (void)startSessionAsServer {	
	// if session has already started and session is in server mode, go to ready screen
	if([[GameManager sharedGameManager] isMultiplayer] && [[GameManager sharedGameManager] isServer]) {
		[self goToReadyScreen];
		return;
	}
	
	[[GameManager sharedGameManager] startSessionWithIsServer:YES];
	[[GameManager sharedGameManager] setIsServer:YES];
	[[GameManager sharedGameManager] setIsMultiplayer:YES];
	[self goToReadyScreen];
}

- (void)startSessionAsClient {
	// if session has already started and session is in client mode, disconnect from all peers, then reconnect
	if([[GameManager sharedGameManager] isMultiplayer] && ![[GameManager sharedGameManager] isServer]) {
		[[GameManager sharedGameManager] disconnect];
		[self connectToServer];
		return;
	}
	
	[[GameManager sharedGameManager] startSessionWithIsServer:NO];	
	[[GameManager sharedGameManager] setIsServer:NO];
	[[GameManager sharedGameManager] setIsMultiplayer:YES];
	
	// wait and try connecting
	[self runAction:[CCSequence actions:[CCDelayTime actionWithDuration:.5], 
					 [CCCallFunc actionWithTarget:self selector:@selector(connectToServer)],
					 nil]];
	
	// if fail
	// the networking class shows an error message
	// can click join again to retry connecting
	
	// if success
	// the networking class sends a notification of success which triggers connectionWasSuccessful
	// start game
}

- (void)connectToServer {
	[[GameManager sharedGameManager] connectToServer];
	// todo: create connectAndReplyTo function, should return bool
	// handle sending device sequence position in this function
	// come back here and run was successful (ready screen) or failed (do nothing)
	
}

- (void)connectionWasSuccessful:(NSNotification*)notification { // todo: should delegate GameManager to handle this?
	NSLog(@"connectionWasSuccessful");
	BOOL isServer = [[GameManager sharedGameManager] isServer];
	
	// when a new device is connected
	// server and client fire this event
	// server sends device sequence positions to all of the clients
	
	// let game manager handle this first
	// could just wait
	
	if (!isServer) {
		[self runAction:[CCSequence actions:[CCDelayTime actionWithDuration:.5], 
						 [CCCallFunc actionWithTarget:self selector:@selector(goToReadyScreen)],
						 nil]];
		//[self goToReadyScreen];
	}
}

- (void)goToReadyScreen {
	[[CCDirector sharedDirector] replaceScene:[ReadyScreen scene]];
}

@end
