//
//  Team.h
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/24/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class ButtonGroup;
@class Athlete;

@interface Team : CCNode {
	ButtonGroup *buttonGroup;
	Athlete *athlete;
	// todo: HUD icon?
	BOOL isTop;
	int currentLap;
	CGFloat currentDistance; // a percentage
	BOOL isEnabled;
}

@property (nonatomic, readwrite, retain) ButtonGroup *buttonGroup;
@property (nonatomic, readwrite, retain) Athlete *athlete;
@property (nonatomic, readwrite, assign) BOOL isTop;
@property (nonatomic, readwrite, assign) int currentLap;
@property (nonatomic, readwrite, assign) CGFloat currentDistance;
@property (nonatomic, readwrite, assign) BOOL isEnabled;

+ (id)initWithIsTop :(BOOL)isTop;
- (id)initWithIsTop :(BOOL)isTop;
- (void)dealloc;
- (void)update :(CGFloat)dt;

@end
