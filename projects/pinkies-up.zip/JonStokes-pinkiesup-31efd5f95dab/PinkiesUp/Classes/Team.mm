//
//  Team.m
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/24/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Global.h"
#import "GameManager.h"
#import "Team.h"
#import "ButtonGroup.h"
#import "Athlete.h"

@implementation Team

@dynamic isEnabled;
@synthesize buttonGroup, athlete, isTop, currentLap, currentDistance;

#pragma mark - overridden functions
+ (id)initWithIsTop :(BOOL)isTop {
	return [[self alloc] initWithIsTop :isTop];
}

- (id)initWithIsTop :(BOOL)_isTop {
	if (!(self = [super init]))
		return nil;
	
	CCLOG(@"initializing a Team");
	
	isTop = _isTop;
	currentLap = 0;
	currentDistance = 0.0f;
	//self.isEnabled = YES;
	
	// add athlete
	athlete = [Athlete init:isTop];
	[self addChild:athlete];
	
	// add buttons
	int deviceSequencePosition = [[GameManager sharedGameManager] deviceSequencePosition];
	
	int buttonCount = isTop ? [GameManager sharedGameManager].topButtonCount : [GameManager sharedGameManager].bottomButtonCount;
	NSArray* buttons = [[GameManager sharedGameManager] createButtonsWithIsTop:isTop isReadyScreen:NO buttonCount:buttonCount deviceSequencePosition:deviceSequencePosition];
	buttonGroup = [ButtonGroup initWithButtons:buttons];
	buttonGroup.athlete = athlete;
	[athlete addLegs:buttonCount];
	//[buttonGroup setLinearSequenceWithIsInReverse:isTop];
	[self addChild:buttonGroup];
	
	// set initial athlete position
	[self setInitialAthletePosition];
	
	// flash all buttons
	[buttonGroup flash];
    
	return self;
}

- (void)dealloc {
	[buttonGroup release]; // release this before athlete
	[athlete release];
	[super dealloc];
}

#pragma mark - public functions
- (void)update :(CGFloat)dt {
	CGSize screenSize = [GameManager sharedGameManager].screenSize;
	int buttonCount = [buttonGroup enabledButtonCount];
	int lapCount = [[GameManager sharedGameManager] lapCount];
	
	// todo: temp bugfix, to prevent the hud icons from disappearing during end game
	if (currentLap >= lapCount)
		return;
	
	if (![buttonGroup isEnabled] && ![athlete isStunned])
		[buttonGroup setIsEnabled:YES];
	
	// when a sequence is completed successfully or failed, update velocity
	
	int sequenceIsSuccessful = [buttonGroup update]; //returns sequence success or failure
	
	if (sequenceIsSuccessful == 1 && DEBUG_CONTROL != 1 && ![athlete isStunned]) {
		if(APPLY_IMPULSE_AT_SEQUENCE_FINISH) {
			athlete.torsoBody->ApplyLinearImpulse(b2Vec2(HAROLD_IMPULSE * (buttonCount / MAX_BUTTONS), 0.0f), athlete.torsoBody->GetPosition());
		}
		
	}
	else if (sequenceIsSuccessful == 0) {
		[athlete stun];
		[buttonGroup setIsEnabled:NO];
	}
	
	//update player icon, using distance continuously, based on velocity
	CGFloat buttonWidth = [GameManager sharedGameManager].buttonWidth;
	CGFloat trackLength = [GameManager sharedGameManager].trackLength;
	CGFloat trackEnd = [GameManager sharedGameManager].trackEnd;
	CGFloat trackBegin = [[GameManager sharedGameManager] trackBegin];
	
	currentDistance = ((([athlete torsoX] - trackBegin) / trackLength) / (float)lapCount) + ((float)currentLap / (float)lapCount);
	
	// handle screen transitioning
	BOOL isMultiplayer = [[GameManager sharedGameManager] isMultiplayer];
	
	if (!isMultiplayer) {
		//if (currentLap < lapCount - 1) { // todo: currentLap starts at 0, lapCount starts at 1, choose one!
			[athlete transitionPartsPositionsFromMaxX:trackEnd toMinX:trackBegin];
			[athlete transitionPartsHomePointsFromMaxX:trackEnd toMinX:trackBegin];
		//} // todo: does not work properly until set position is complete
	}
	
	// check if athlete is completing a lap
	// check the team's current lap number
	// if the athlete is at the end of the track, move it to the beginning
	BOOL athleteIsAtEndOfScreen = [athlete torsoX] > trackEnd; // - athlete.size.width
	BOOL isLastDevice = NO; // todo: temp
	BOOL isServer = [[GameManager sharedGameManager] isServer]; // todo: this is unbarably ugly now
	
	if (athleteIsAtEndOfScreen) {
		if (isMultiplayer) {
			// remove athlete and add to next device
			[[GameManager sharedGameManager] setFloatToSend:[athlete linearVelocityX]];
			CCLOG(@"athlete linearVelocityX: %f", [[GameManager sharedGameManager] floatToSend]);
			if (isServer) // todo: add this condition to GameManager
				[[GameManager sharedGameManager] setFloatToReceive:[[GameManager sharedGameManager] floatToSend]];
			[[GameManager sharedGameManager] sendData:(isTop ? kAddTopAthleteToNextDevice : kAddBottomAthleteToNextDevice)];
			
			[self removeAthlete];
			
			if (isLastDevice)
				currentLap++;
			
			return;
		}
		
		// next lap
		currentLap++;
		
		if (currentLap >= lapCount)
			return;
		
		[athlete setTorsoX:trackBegin];
	}
}

#pragma mark - private functions
- (void)setInitialAthletePosition {
	CGSize screenSize = [[GameManager sharedGameManager] screenSize];
	CGFloat trackBegin = [[GameManager sharedGameManager] trackBegin];
	CGFloat buttonHeight = [[GameManager sharedGameManager] buttonHeight];
	CGFloat groundHeight = [[GameManager sharedGameManager] groundHeight];
	
	if (isTop) {
		[athlete setPosition2:ccp(trackBegin, screenSize.height - buttonHeight - groundHeight - 1)];
		athlete.rotation = 180;
	}
	else {
		[athlete setPosition2:ccp(trackBegin, buttonHeight + groundHeight + 1)];
	}
}

#pragma mark - public networking functions
- (void)setIsEnabled:(BOOL)_isEnabled {
	isEnabled = _isEnabled;
	
	if (isEnabled) {
		[buttonGroup setIsEnabled:YES];
		[self addAthlete];	
	}
	else {
		[buttonGroup setIsEnabled:NO];
		[self removeAthlete];
	}
}

- (BOOL)isEnabled {
	return isEnabled;
}

#pragma mark - private networking functions
- (void)removeAthlete {
	[athlete setVisible:NO];
	[athlete setPosition2:ccp(-1000000, -1000000)];
}

- (void)addAthlete {
	[athlete setVisible:YES];
	[self setInitialAthletePosition];
}

@end
