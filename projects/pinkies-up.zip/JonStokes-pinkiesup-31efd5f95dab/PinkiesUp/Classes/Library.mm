//
//  Library.m
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/23/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Library.h"

@implementation Library

+ (id)alloc {
	[NSException raise:@"Cannot be instantiated!" format:@"Static class 'ClassName' cannot be instantiated!"];
	return nil;
}

// todo: use C++ arrays and vectors with float or convert to NSArrays and NSMutableArrays with CGFloat?
// mixing C++ seems to work so far!
 
+ (int)IsPointInPolygonWithVector:(const std::vector<CGPoint> &)vert :(int)nvert :(float)testx :(float)testy {
	int i, j, c = 0;
	for (i = 0, j = nvert-1; i < nvert; j = i++) {
		if ( ((vert[i].y>testy) != (vert[j].y>testy)) &&
			(testx < (vert[j].x-vert[i].x) * (testy-vert[i].y) / (vert[j].y-vert[i].y) + vert[i].x) )
			c = !c;
	}
	return c;
}

+ (void)drawTrianglesWithVertices:(const std::vector<float> &)v // todo: add dimensions = 2
{	
	// Default GL states: GL_TEXTURE_2D, GL_VERTEX_ARRAY, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
	// Needed states: GL_VERTEX_ARRAY,
	// Unneeded states: GL_TEXTURE_2D, GL_TEXTURE_COORD_ARRAY, GL_COLOR_ARRAY
	
	//glEnableClientState(GL_VERTEX_ARRAY);
	glDisable(GL_TEXTURE_2D);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	
	glVertexPointer(2, GL_FLOAT, 0, &v[0]); // dimensions
	glDrawArrays(GL_TRIANGLES, 0, v.size()/2); // number of indices
	
	//glDisableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glEnable(GL_TEXTURE_2D);
}

+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)message cancelButtonTitle:(NSString *)cancelButtonTitle {
	//[self closeCurrentPopup]; // todo: need to close last popup?
	
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
															   message:message
															  delegate:nil
													 cancelButtonTitle:cancelButtonTitle
													 otherButtonTitles:nil];
	
	[alertView show];
	[alertView release];
}

+ (void)showErrorAlertWithMessage:(NSString *)messsage {
	[self showAlertWithTitle:@"OMG. YOU BROKE IT." message:messsage cancelButtonTitle:@"NUH-UH"];
}

@end
