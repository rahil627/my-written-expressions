//
//  AthletePart.mm
//  PinkiesUp
//
//  Created by Jon Stokes on 5/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "AthletePart.h"


@implementation AthletePart

@synthesize homePosition, body, followBody, canFollowBody;

@end
