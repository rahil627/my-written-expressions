//
//  EndMenu.h
//  PinkiesUp
//
//  Created by Rahil Patel on 5/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CCLayer.h"

@interface EndMenu : CCLayer {
	
}

// temporary end menu
+ (id)init;
- (void)showWithTimer:(CGFloat)timer topTeamWon:(BOOL)topTeamWon;

@end