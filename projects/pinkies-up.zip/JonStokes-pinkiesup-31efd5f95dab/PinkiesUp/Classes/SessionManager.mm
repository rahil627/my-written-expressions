/*
 
 File: SessionManager.m
 Abstract: Delegate for the session and sends notifications when it changes.
 Version: 1.0
 
 */

#import "SessionManager.h"
#import "NetworkingConstants.h"
#import "Library.h"

/*
@interface SessionManager ()

- (Device *)addDevice:(NSString *)peerID;
- (void)removeDevice:(Device *)device;
- (NSDictionary *)getDeviceInfo:(Device *)device;

@end
*/

@implementation SessionManager

#pragma mark - public functions
- (id)initWithDataHandler:(DataHandler *)handler devicesManager:(DevicesManager *)manager sessionMode:(GKSessionMode)sessionMode {
	if (!(self = [super init]))
		return nil;
	
	devicesManager = manager;

	session = [[GKSession alloc] initWithSessionID:nil displayName:nil sessionMode:sessionMode];
	session.delegate = self;
	[session setDataReceiveHandler:handler withContext:nil];
	//session.disconnectTimeout = 20; // default
	
	dataHandler = handler; // todo: for sending to all
	
	NSLog(@"SessionManager initWithDataHandler peerID: %@", session.peerID);
	
	return self;
}

- (void)dealloc {
	NSLog(@"SessionManager dealloc");
	session.delegate = nil; // don't think this is needed
	[session disconnectFromAllPeers];
	[session release];
	[super dealloc];
}

- (void)start {
	NSLog(@"session available = YES");
	session.available = YES;
}

// todo: hackish solution for sendDataToAllPeers
- (void)sendToAllDevices {
	NSLog(@"sendToAllDevices");
	
	// Sets the DataHandler to occupied
	//	currentState = DHSSending;
	//	currentStateRelatedDevice = device;
	
	[dataHandler prepareData];
	NSData* data = [dataHandler getDataToSend];
	
	[session sendDataToAllPeers:data withDataMode:GKSendDataReliable error:nil];
	// todo: add error handling
}

// todo: hackish solution
- (NSString*)thisDevicePeerID {
	return [session peerID];
}

// todo: hackish solution
- (void)disconnectFromAllDevices {
	[session disconnectFromAllPeers];
}

#pragma mark - private session protocol functions
- (void)session:(GKSession *)s peer:(NSString *)peerID didChangeState:(GKPeerConnectionState)state {
	Device *currentDevice = [devicesManager deviceWithID:peerID];
	
	// Instead of trying to respond to the event directly, it delegates the events.
	// The availability is checked by the main ViewController.
	// The connection is verified by each Device.
	switch (state) {			
		case GKPeerStateAvailable:
			NSLog(@"session didChangeState state: GKPeerStateAvailable");
		case GKPeerStateConnecting:
			NSLog(@"session didChangeState state: GKPeerStateConnecting");
			if (!currentDevice) {
				currentDevice = [self addDevice:peerID];
				NSLog(@"session didChangeState state: GKPeerStateConnecting addDevice peerID: %@", peerID);
				[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_DEVICE_AVAILABLE object:nil userInfo:[self getDeviceInfo:currentDevice]];
			}
			break;
			
		case GKPeerStateUnavailable:
			NSLog(@"session didChangeState state: GKPeerStateUnavailable");
			if (currentDevice) {
				[currentDevice retain];
				[self removeDevice:currentDevice];
				[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_DEVICE_UNAVAILABLE object:nil userInfo:[self getDeviceInfo:currentDevice]];
				[currentDevice release];
			}
			break;
			
		case GKPeerStateConnected:
			NSLog(@"session didChangeState state: GKPeerStateConnected");
			if (currentDevice) {
				// caught by device
				[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_DEVICE_CONNECTED object:nil userInfo:[self getDeviceInfo:currentDevice]];
			}
			break;

		case GKPeerStateDisconnected:
			NSLog(@"session didChangeState state: GKPeerStateDisconnected");
			if (currentDevice) {
				// caught by device
				[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_DEVICE_DISCONNECTED object:nil userInfo:[self getDeviceInfo:currentDevice]];
				
				if (s.peerID == session.peerID) {
					[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_THIS_DEVICE_DISCONNECTED object:nil userInfo:[self getDeviceInfo:currentDevice]];
					
					[Library showErrorAlertWithMessage:@"A device was disconnected"];
				}
			}
			break;
	}
}

- (void)session:(GKSession *)session didReceiveConnectionRequestFromPeer:(NSString *)peerID {
	NSLog(@"session:didReceiveConnectionRequestFromPeer");
	[session acceptConnectionFromPeer:peerID error:nil];
	NSLog(@"session:acceptConnectionFromPeer");
}

- (void)session:(GKSession *)session connectionWithPeerFailed:(NSString *)peerID withError:(NSError *)error {
	NSLog(@"session:connectionWithPeerFailed error: %@", [error localizedDescription]);
	Device *currentDevice = [devicesManager deviceWithID:peerID];
	
	// Does the same thing as the didStateChange method. It tells a Device that the connection failed.
	if (currentDevice) {
		[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_DEVICE_CONNECTION_FAILED object:nil userInfo:[self getDeviceInfo:currentDevice]];
	}
}

- (void)session:(GKSession *)session didFailWithError:(NSError *)error {
	NSLog(@"session:didFailWithError");
	[Library showErrorAlertWithMessage:@"session failed: %@"];
}

#pragma mark - private functions
- (Device *)addDevice:(NSString *)peerID {
	NSLog(@"addDevice peerID: %@", peerID);
	Device *device = [[Device alloc] initWithSession:session peer:peerID];
	[devicesManager addDevice:device];
	[device release];
	
	return device;
}

- (void)removeDevice:(Device *)device {
	[devicesManager removeDevice:device];
}

- (NSDictionary *)getDeviceInfo:(Device *)device {
	return [NSDictionary dictionaryWithObject:device forKey:DEVICE_KEY];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	exit(0);
}

@end
