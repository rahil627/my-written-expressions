//
//  TestScene.h
//  PinkiesUp
//
//  Created by Rahil Patel on 6/4/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface MenuScreen : CCLayer {
	CCLabelTTF *devicesCountLabel;
}

+ (CCScene *) scene;

@end

