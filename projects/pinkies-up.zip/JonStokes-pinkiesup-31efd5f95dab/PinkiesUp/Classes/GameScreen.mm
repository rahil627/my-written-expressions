//
//  GameScreen.m
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/18/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import "GameScreen.h"
#import "Library.h"
#import "Global.h"
#import "GameManager.h"
#import "Team.h"
#import "HUD.h"
#import "Athlete.h"
#import "ReadyScreen.h"
#import "AthletePart.h"
#import "EndMenu.h"
#import "MenuScreen.h"

EndMenu *endMenu; // global?

@implementation GameScreen

+(CCScene *) scene {
	CCScene *scene = [CCScene node];
	GameScreen *gameScreen = [GameScreen node];
	[scene addChild: gameScreen];
	endMenu = [EndMenu init];
	[scene addChild:endMenu];
	return scene;
}

#pragma mark - overridden functions
-(id) init {
	if(!(self=[super init]))
		return nil;
	
	// set CCLayer properties
	self.isTouchEnabled = YES;
	
	// set some game related GameManager members
    screenSize = [CCDirector sharedDirector].winSize;
    [GameManager sharedGameManager].screenSize = screenSize;
	[GameManager sharedGameManager].trackLength = screenSize.width - [GameManager sharedGameManager].buttonWidth * 2;
	[GameManager sharedGameManager].trackBegin = [GameManager sharedGameManager].buttonWidth;
	[GameManager sharedGameManager].trackEnd = [GameManager sharedGameManager].screenSize.width - [GameManager sharedGameManager].buttonWidth;
	
    // box2d
    [self setupWorld];
	
	// add sprites
	hud = [HUD init];
	[self addChild:hud];
	
	topTeam = [Team initWithIsTop:YES];
	[[topTeam buttonGroup] setIsEnabled:NO]; // doing this without including the buttonGroup header file! objective-C magic
	[self addChild:topTeam];
	
	bottomTeam = [Team initWithIsTop:NO];
	[[bottomTeam buttonGroup] setIsEnabled:NO];
	[self addChild:bottomTeam];
	
	// if not the first device in the sequence, remove athlete
	if ([[GameManager sharedGameManager] isMultiplayer] && ![[GameManager sharedGameManager] isServer]) {
		[topTeam setIsEnabled:NO];
		[bottomTeam setIsEnabled:NO];
	}
	
	// add countdown
	countdownTimer = 5.0f;
    countdownLabel = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%i", (int)ceilf(countdownTimer)] 
							fontName:@"Arial" fontSize:32];
    countdownLabel.position = ccp(screenSize.width / 2, screenSize.height / 2);
    [self addChild:countdownLabel];
	
	// add end game menu related stuff
	hasEnded = NO;
	timer = 0.0f;
	
	// add pause game menu related stuff
	paused = NO;
	[self addPauseMenu];
	
	
	// add schedulers (event listeners)
	//[self schedule: @selector(update:) interval:0.0f repeat:kCCRepeatForever delay:5.0f]; //default interval is set to 60, in CCDirector, kDefaultFPS directive constant
    [self schedule:@selector(updateCountdown:)];
	
	return self;
}

- (void) dealloc {
	// box2d
	delete world;
	world = NULL;
	delete m_debugDraw;
	
	[hud release]; // todo: temporary fix
	
	[super dealloc];
}

- (void) draw {
    if(DEBUG_DRAW == 1 ) {
        
        // Default GL states: GL_TEXTURE_2D, GL_VERTEX_ARRAY, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
        // Needed states:  GL_VERTEX_ARRAY, 
        // Unneeded states: GL_TEXTURE_2D, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
        glDisable(GL_TEXTURE_2D);
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
        
        world->DrawDebugData();
        
        // restore default GL states
        glEnable(GL_TEXTURE_2D);
        glEnableClientState(GL_COLOR_ARRAY);
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    }
}

-(void) ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
		
	//cycle through touches
	for( UITouch *touch in touches ) {
		
		CGPoint location = [touch locationInView: [touch view]];
		location = [[CCDirector sharedDirector] convertToGL: location];
		
		if(ccpDistance(location, pauseButton.position) < 3.0f*pauseButton.contentSize.width/2) {
			if(paused) {
				[self unpause];
			} else {
				[self pause];
			}
		}
		
	}
}

#pragma mark - main function
- (void) update: (ccTime)dt { // delta time
	
	timer += dt;
	
	if ([[GameManager sharedGameManager] isMultiplayer])
		[self handleReceivedClientData];
	
    [topTeam update: dt];
	[bottomTeam update: dt];
	
	[hud updateWithTopTeamDistance:topTeam.currentDistance bottomTeamDistance:bottomTeam.currentDistance];
    
	// box2d
    int32 velocityIterations = 8;
	int32 positionIterations = 1;
	
	// Instruct the world to perform a single step of simulation. It is
	// generally best to keep the time step and iterations fixed.
	world->Step(dt, velocityIterations, positionIterations);
    
    for (b2Body* b = world->GetBodyList(); b; b = b->GetNext())
	{
		if (b->GetUserData() != NULL) {
			//Synchronize the sprite position and rotation with the corresponding body
			CCSprite *myActor = (CCSprite*)b->GetUserData();
            if(myActor.parent != nil) {
                //child positioning is relative to parent, so you have to convert from absolute to node space
                myActor.position = [myActor.parent convertToNodeSpace:CGPointMake(b->GetPosition().x * PTM_RATIO, b->GetPosition().y * PTM_RATIO)];
				if([myActor isKindOfClass:[AthletePart class]])
					myActor.rotation = -1 * CC_RADIANS_TO_DEGREES(b->GetAngle());


            }
            else  {
				myActor.position = CGPointMake(b->GetPosition().x * PTM_RATIO, b->GetPosition().y * PTM_RATIO);

			}
                

        }
    }
    
    topTeam.athlete.torsoBody->ApplyForce(b2Vec2(0.0f,-WORLD_GRAVITY), topTeam.athlete.torsoBody->GetPosition());
    bottomTeam.athlete.torsoBody->ApplyForce(b2Vec2(0.0f,WORLD_GRAVITY), bottomTeam.athlete.torsoBody->GetPosition());
	
    // after box2d
	
	// check if game is over
	int lapCount = [[GameManager sharedGameManager] lapCount];
	
	if ((topTeam.currentLap >= lapCount || bottomTeam.currentLap >= lapCount) && !hasEnded)	
		[self endGame];
	
}

- (void) endGame {
	BOOL topTeamWon;
	CGFloat buttonWidth = [GameManager sharedGameManager].buttonWidth;
	
	hasEnded = YES;
	topTeamWon = topTeam.athlete.torsoBody->GetPosition().x * PTM_RATIO >= screenSize.width - buttonWidth;
	[endMenu showWithTimer:timer topTeamWon:topTeamWon];
}

#pragma mark - private functions
- (void) setupWorld {
    
    // Define the gravity vector.
    b2Vec2 gravity;
    gravity.Set(0.0f, 0.0f);
    
    // Do we want to let bodies sleep?
    // This will speed up the physics simulation
    bool doSleep = true;
    
    // Construct a world object, which will hold and simulate the rigid bodies.
    world = new b2World(gravity, doSleep);
    
    world->SetContinuousPhysics(true);
    
    if(DEBUG_DRAW) {
    
        // Debug Draw functions
        m_debugDraw = new GLESDebugDraw(PTM_RATIO);
        world->SetDebugDraw(m_debugDraw);
        
        uint32 flags = 0;
        flags += b2DebugDraw::e_shapeBit;
        flags += b2DebugDraw::e_jointBit;
        //flags += b2DebugDraw::e_aabbBit;
        //flags += b2DebugDraw::e_pairBit;
        //flags += b2DebugDraw::e_centerOfMassBit;
        m_debugDraw->SetFlags(flags);		
        
    }
    
    // Define the ground body.
    b2BodyDef groundBodyDef;
    groundBodyDef.position.Set(0, 0); // bottom-left corner
    
    // Call the body factory which allocates memory for the ground body
    // from a pool and creates the ground box shape (also from a pool).
    // The body is also added to the world.
    b2Body* groundBody = world->CreateBody(&groundBodyDef);
    
    // Define the ground box shape.
    b2PolygonShape groundBox;
	
	CGFloat buttonHeight = [GameManager sharedGameManager].buttonHeight;
	CGFloat groundHeight = screenSize.height * (40.0f/768.0f);
	[GameManager sharedGameManager].groundHeight = groundHeight;
    
    // bottom
    groundBox.SetAsEdge(b2Vec2(0, buttonHeight / PTM_RATIO + groundHeight / PTM_RATIO),
						b2Vec2(screenSize.width / PTM_RATIO, buttonHeight / PTM_RATIO + groundHeight / PTM_RATIO));
    groundBody->CreateFixture(&groundBox,0);
    
    // top
    groundBox.SetAsEdge(b2Vec2(0, screenSize.height / PTM_RATIO - buttonHeight / PTM_RATIO - groundHeight / PTM_RATIO),
						b2Vec2(screenSize.width/PTM_RATIO, screenSize.height / PTM_RATIO - buttonHeight / PTM_RATIO - groundHeight / PTM_RATIO));
    groundBody->CreateFixture(&groundBox, 0);
    
    // left
    groundBox.SetAsEdge(b2Vec2(0,screenSize.height/PTM_RATIO), b2Vec2(0,0));
    groundBody->CreateFixture(&groundBox,0);
    
    // right
    groundBox.SetAsEdge(b2Vec2(screenSize.width/PTM_RATIO,screenSize.height/PTM_RATIO), b2Vec2(screenSize.width/PTM_RATIO,0));
    groundBody->CreateFixture(&groundBox,0);
    
    [GameManager sharedGameManager].world = world;
}

- (void)updateCountdown:(ccTime)dt {
	countdownTimer -= dt;

	if (countdownTimer > 0 ) {
		[countdownLabel setString:[NSString stringWithFormat:@"%i", (int)ceilf(countdownTimer)]];
	}
	else if (countdownTimer <= 0 && countdownTimer > -2) {
		if (![[countdownLabel string]isEqualToString:@"GO"]) {
			[[bottomTeam buttonGroup] setIsEnabled:YES];
			[[topTeam buttonGroup] setIsEnabled:YES];
			[countdownLabel setString:[NSString stringWithString:@"GO"]];
			[self schedule: @selector(update:)];
		}
	}
	else if (countdownTimer <= -2) {
		[self removeChild:countdownLabel cleanup:YES];
		[self unschedule:@selector(updateCountdown:)];
	}
}

-(void) pause {
	CCLOG(@"pause!");
	pauseMenuLayer.visible = YES;
	paused = YES;
	[[CCActionManager sharedManager] pauseTarget:self];
}

-(void) unpause {
	CCLOG(@"unpause!");
	pauseMenuLayer.visible = NO;
	paused = NO;
	[[CCActionManager sharedManager] resumeTarget:self];

}

-(void) addPauseMenu {
	CGFloat buttonWidth = [[GameManager sharedGameManager] buttonWidth];
	CGFloat beginningOfLineX = [hud beginningOfLineX];
	CGFloat pauseButtonX = (buttonWidth + beginningOfLineX) / 2;
	
	//add pause button
	pauseButton = [CCSprite spriteWithFile:@"pausebutton.png"];
	pauseButton.position = ccp(pauseButtonX, screenSize.height/2.0f);
	pauseButton.scale = 0.7f;
	[self addChild:pauseButton];
	
	//create layer
	pauseMenuLayer = [CCLayerColor layerWithColor:ccc4(150, 150, 150, 150)/* width:849 height:548*/]; 
	//pauseMenuLayer.position = ccp(screenSize.width/2 - 849*0.8f/2, screenSize.height/2 - 548*0.8f/2);
	pauseMenuLayer.anchorPoint = ccp(0,0);
	[self addChild:pauseMenuLayer]; 
	pauseMenuLayer.visible = NO;
	
	CCMenuItemFont* item1 = [CCMenuItemFont itemFromString:@"Restart" target:self selector:@selector(restartCurrentGame)];
	CCMenuItemFont* item2 = [CCMenuItemFont itemFromString:@"Main Menu" target:self selector:@selector(goToMenuScreen)];
	CCMenu* menu = [CCMenu menuWithItems:item1, item2, nil];
	menu.position = ccp(self.contentSize.width/2,self.contentSize.height/2);
	[menu setColor:ccWHITE];
	[pauseMenuLayer addChild:menu z:1];
	[menu alignItemsVerticallyWithPadding:40];
	
}

-(void) restartCurrentGame {
	CCLOG(@"restart!");
	[[CCDirector sharedDirector] replaceScene:[GameScreen scene]];
	
}

-(void) goToMenuScreen {
	
	[[CCDirector sharedDirector] replaceScene:[MenuScreen scene]];

}

#pragma mark - networking functions
- (void)handleReceivedClientData {
	// handle game related client networking data here
	
	int data = [[GameManager sharedGameManager] dataReceived];
	
	if (data == kEmpty)
		return;
	
	CCLOG(@"GameScreen handleReceivedNetworkData data: %i", data);
	
	switch (data) {	
		case kAddTopAthlete:
			[topTeam setIsEnabled:YES];
			[[topTeam athlete] setLinearVelocityX:[[GameManager sharedGameManager] floatToReceive]];
			CCLOG(@"top team linear velocity: %f", [[GameManager sharedGameManager] floatToReceive]);
			break;
			
		case kAddBottomAthlete:
			[bottomTeam setIsEnabled:YES];
			[[bottomTeam athlete] setLinearVelocityX:[[GameManager sharedGameManager] floatToReceive]];
			CCLOG(@"bottom team linear velocity: %f", [[GameManager sharedGameManager] floatToReceive]);
			break;
			
		case kStartGame:
			[[CCDirector sharedDirector] replaceScene:[ReadyScreen scene]]; // todo: temp
			break;
			
		case kEndGame:
			[self endGame];
			[self scheduleOnce:@selector(goToReadyScreen) delay:10];
			break;
			
		case kResetGame:
			[[CCDirector sharedDirector] replaceScene:[MenuScreen scene]]; // todo: temp
			break;
			
		default:
			CCLOG(@"GameScreen handleReceivedNetworkData bad client data is bad: %i", data);
			break;
	}
	
	[[GameManager sharedGameManager] setDataReceived:kEmpty];
}

 - (void)goToReadyScreen {
	 [[CCDirector sharedDirector] replaceScene:[ReadyScreen scene]];
 }
			 
@end
