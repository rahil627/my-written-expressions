#import "PinkiesUpDataHandler.h"
#import "PinkiesUpDataProvider.h"

@implementation PinkiesUpDataHandler

- (NSObject<DataProvider> *)createDataProvider {
	return [[PinkiesUpDataProvider alloc] init];
}

@end
