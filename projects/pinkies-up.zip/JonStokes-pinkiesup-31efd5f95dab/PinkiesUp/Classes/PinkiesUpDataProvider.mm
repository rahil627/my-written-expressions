/*
 
 File: ContactDataProvider.m
 Abstract: Implementation of the DataProvider specifically for beaming contacts.
 Version: 1.0
 
*/

#import "PinkiesUpDataProvider.h"
#import "GameManager.h"

@implementation PinkiesUpDataProvider

//@synthesize dataToSend, dataReceived;

- (id)initWithGameManager:(GameManager *)g {
	if (!(self = [super init]))
		return nil;
	
	gameManager = g;
	serializedData = nil;
	
	return self;
}

#pragma mark - protocol functions
- (void)prepareDataAndReplyTo:(id)delegate selector:(SEL)dataPreparedSelector {
	NSLog(@"prepareDataAndReplyTo");
	
	delegateToCall = delegate;
	selectorToCall = dataPreparedSelector;
	
	if (serializedData != nil) { // NSData is immutable, so have to recreate every time
		[serializedData release];
		serializedData = nil;
	}
	
	// get data
	int dataToSend = [[GameManager sharedGameManager] dataToSend]; // todo: rename to dataTypeToSend
	
	// serialize data
	NSMutableData* mutableData = [NSMutableData data];
	//uint32_t theInt = htonl((uint32_t)myInteger); // convert from host (your machine) to network endiannes
	[mutableData appendBytes:&dataToSend length:sizeof(dataToSend)];
	
	int i;
	float f;
	switch (dataToSend) {
		case kSendDeviceSequencePosition:
			i = [[GameManager sharedGameManager] integerToSend]; // sequence position
			[mutableData appendBytes:&i length:sizeof(i)];
			break;
			
		case kAddTopAthleteToNextDevice:
		case kAddTopAthlete:
		case kAddBottomAthleteToNextDevice:
		case kAddBottomAthlete:
			f = [[GameManager sharedGameManager] floatToSend]; // linear velocity x
			NSLog(@"prepareDataAndReplyTo floatToSend:%f", f);
			[mutableData appendBytes:&f length:sizeof(f)];
			break;
			
		default:
			break;
	}
	
	serializedData = [[NSData dataWithData:mutableData] retain];
	
	NSLog(@"prepareDataAndReplyTo: data to send: %i size: %u", dataToSend, [serializedData length]);
	
	if (delegateToCall && [delegateToCall respondsToSelector:selectorToCall])
		[delegateToCall performSelector:selectorToCall];
}

- (NSString *)getLabelOfDataToSend {
	NSLog(@"getLabelOfDataToSend");
	return @"LabelOfDataToSend";
}

- (NSData *)getDataToSend {
	NSLog(@"getDataToSend");
	return serializedData;
}

- (BOOL)storeData:(NSData*)data andReplyTo:(id)delegate selector:(SEL)selector {
	delegateToCall = delegate;
	selectorToCall = selector;
	
	NSLog(@"storeData");
	
	// todo: add more error handling
	// check if this packet is newer than the last packet received (see GKTank)
	// check if the length of the packet is correct
	
	// use buffer
//	char buffer[4];
//	[data getBytes:buffer length:4];
//	
//	int dataSize = 0;
//	char cBuf2[4];
//	for(int k=0;k < 4; ++k)
//		{ cBuf2[k] = buffer[3-k]; }
//	
//	memcpy(&dataSize, cBuf2, 4);
//	NSLog(@"Zip stream size :%d", dataSize);
	
	// deserialize data
	int dataType;
	int i = -1; // todo: use 0?
	float f = -1.0f;
	NSData* subData;
	@try {
		[data getBytes:&dataType length:sizeof(dataType)];
		
		switch (dataType) {
			case kSendDeviceSequencePosition:
				subData = [data subdataWithRange:NSMakeRange(4, sizeof(i))];
				[subData getBytes:&i length:sizeof(i)];
				break;
				
			case kAddTopAthleteToNextDevice:
			case kAddTopAthlete:
			case kAddBottomAthleteToNextDevice:
			case kAddBottomAthlete:
				subData = [data subdataWithRange:NSMakeRange(4, sizeof(f))];
				[subData getBytes:&f length:sizeof(f)];
				break;
		}
	}
	@catch (NSException * e) {
		NSLog(@"failed to deserialize data, exception: name:%@ reason:%@", [e name], [e reason]);
		return NO;
	}
	
	// handle data
	[[GameManager sharedGameManager] dataWasReceived:dataType];
	
	if (i != -1) {
		[[GameManager sharedGameManager] setIntegerToReceive:i];
		NSLog(@"storeData received integer:%i",[[GameManager sharedGameManager] integerToReceive]);
	}
	
	if (f != -1.0f) {
		[[GameManager sharedGameManager] setFloatToReceive:f];
		NSLog(@"storeData received float:%f",[[GameManager sharedGameManager] floatToReceive]);
	}
	 
	NSLog(@"storeData: received %i", dataType);
	
	return YES;
}

@end
