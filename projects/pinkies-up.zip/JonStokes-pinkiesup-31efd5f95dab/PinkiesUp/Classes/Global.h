//
//  Global.h
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/23/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define PTM_RATIO 32
#define WORLD_GRAVITY -20.0
#define AUTO_START 0
#define DEBUG_CONTROL 0
#define DEBUG_DRAW 0

#define HAROLD_PIXEL_SCALE 30.0
#define DEFAULT_HAROLD_SCALE (IS_IPAD ? .25f : .125f)
#define APPLY_IMPULSE_AT_SEQUENCE_FINISH 0 // or at end of sequence or button press?
#define HAROLD_IMPULSE (IS_IPAD ? 8.0f : 8.0f * 6.0f/23.0f) // 8.0f ~= 10 * 5 button presses
#define STUN_TIME 2.0f

#define IPAD_BUTTON_WIDTH_FACTOR 1.0f
#define IPAD_BUTTON_HEIGHT_FACTOR 1.0f
#define IPHONE_BUTTON_WIDTH_FACTOR 1.05f
#define IPHONE_BUTTON_HEIGHT_FACTOR 1.3f // to compensate for the petty human's inability to shrink their fingers
#define MIN_BUTTONS 2
#define MAX_BUTTONS 5 // (IS_IPAD ? 5 : 4)
#define FLASH_LENGTH .15f

#define LAPS 3 // todo: currently multiplayer ignores this and has one lap

/** static class that holds global variables */
@interface Global : NSObject {

}

@end

