//
//  NetworkingConstants.h
//  PinkiesUp
//
//  Created by Rahil Patel on 6/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef PinkiesUp_NetworkingConstants_h
#define PinkiesUp_NetworkingConstants_h

//#import <Foundation/Foundation.h>

// notifications
#define NOTIFICATION_DEVICE_AVAILABLE @"notif_device_available"
#define NOTIFICATION_DEVICE_UNAVAILABLE @"notif_device_unavailable"
#define NOTIFICATION_DEVICE_CONNECTED @"notif_device_connected"
#define NOTIFICATION_DEVICE_CONNECTION_FAILED @"notif_device_connection_failed"
#define NOTIFICATION_DEVICE_DISCONNECTED @"notif_device_disconnected"

#define NOTIFICATION_THIS_DEVICE_DISCONNECTED @"notif_this_device_disconnected"

#define NOTIFICATION_THIS_DEVICE_CONNECTED @"notif_this_device_connected"
#define NOTIFICATION_THIS_DEVICE_CONNECTION_FAILED @"notif_this_device_connection_failed"

// the notifications user info dictionary contain a Device object associated to this key
#define DEVICE_KEY @"device"

#endif
