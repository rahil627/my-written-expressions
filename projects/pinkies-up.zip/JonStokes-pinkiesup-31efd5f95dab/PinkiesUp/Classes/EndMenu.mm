//
//  EndMenu.m
//  PinkiesUp
//
//  Created by Rahil Patel on 5/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "EndMenu.h"
#import "Global.h"
#import "GameManager.h"
#import "GameScreen.h"
#import "ReadyScreen.h"

@implementation EndMenu

#pragma mark overridden functions
+ (id)init {
	return [[self alloc] init];
}

- (id) init {
	if (!(self = [super init]))
		return nil;
	
	return self;
}

- (void) dealloc {
	[super dealloc];
}

#pragma mark public functions
- (void)showWithTimer:(CGFloat)timer topTeamWon:(BOOL)topTeamWon {
	CGSize screenSize = [CCDirector sharedDirector].winSize;
	CGFloat textHeight;
	CGFloat textSpacer;
	CGFloat centerY;
	BOOL isMultiplayer = [[GameManager sharedGameManager] isMultiplayer];

	// dim the game layer
	CCLayerColor* colorLayer = [CCLayerColor layerWithColor:ccc4(0, 0, 0, 255)];
	[colorLayer setOpacity:175];
	[self addChild:colorLayer z:1];

	// indicate winning player
	NSString *labelString;

	labelString = topTeamWon ? @"Top Team Wins!" : @"Bottom Team Wins!";

	CCLabelTTF *winnerLabel = [CCLabelTTF labelWithString:labelString fontName:@"Arial" fontSize:32];
	textHeight = winnerLabel.contentSize.height;
	textSpacer = textHeight + 5;
	centerY = (screenSize.height / 2) + (textSpacer * 6) / 2;
	winnerLabel.position = ccp(screenSize.width/2, centerY - textSpacer);
	[self addChild:winnerLabel z:2];

	// adjust and add score
	topTeamWon ? [GameManager sharedGameManager].topTeamScore++ : [GameManager sharedGameManager].bottomTeamScore++;

	int topTeamScore = [GameManager sharedGameManager].topTeamScore;
	int bottomTeamScore = [GameManager sharedGameManager].bottomTeamScore;

	NSString *scoreLabelString = [NSString stringWithFormat:@"%i-%i %@",
								  topTeamScore >= bottomTeamScore ? topTeamScore : bottomTeamScore,
								  topTeamScore < bottomTeamScore ? topTeamScore : bottomTeamScore,
								  topTeamScore >= bottomTeamScore ? @"Top" : @"Bottom"];

	CCLabelTTF *scoreLabel = [CCLabelTTF labelWithString:scoreLabelString fontName:@"Arial" fontSize:32];
	scoreLabel.position = ccp(screenSize.width/2, centerY - textSpacer * 2);
	[self addChild:scoreLabel z:2];
	
	// add track times
	NSString *trackTimeString = [NSString stringWithFormat:@"Track Time: %.02fs", timer];
	CCLabelTTF *trackTimeLabel = [CCLabelTTF labelWithString:trackTimeString fontName:@"Arial" fontSize:32];
	trackTimeLabel.position = ccp(screenSize.width/2, centerY - textSpacer * 3);
	[self addChild:trackTimeLabel z:2];
	
	if (!isMultiplayer) {
		// add menu
		CGSize s = [CCDirector sharedDirector].winSize;

		CCLabelTTF* replayLabel = [CCLabelTTF labelWithString:@"Replay" fontName:@"Arial" fontSize:32];
		CCMenuItemLabel* replayMenuItem = [CCMenuItemLabel itemWithLabel:replayLabel target:self selector:@selector(restart)];
		replayMenuItem.position = ccp(s.width / 2, centerY - textSpacer * 5);

		CCLabelTTF* changePlayersLabel = [CCLabelTTF labelWithString:@"Change Players" fontName:@"Arial" fontSize:32];
		CCMenuItemLabel* changePlayersMenuItem = [CCMenuItemLabel itemWithLabel:changePlayersLabel target:self selector:@selector(goToReadyScreen)];
		changePlayersMenuItem.position = ccp(s.width / 2, centerY - textSpacer * 6);
		CCMenu *menu = [CCMenu menuWithItems:replayMenuItem, changePlayersMenuItem, nil];
		menu.position = ccp(0, 0);
		
		[self addChild:menu z:2];
	}
}

#pragma mark private functions
- (void) restart {
	[[CCDirector sharedDirector] replaceScene:[GameScreen scene]];
}

- (void) goToReadyScreen {
	[[CCDirector sharedDirector] replaceScene:[ReadyScreen scene]];
}

@end