//
//  ButtonGroup.m
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/19/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "ButtonGroup.h"
#import "Button.h"
//#import "NSMutableArray_Shuffling.h"
#import "Athlete.h"

@implementation ButtonGroup

@dynamic isEnabled;
@synthesize athlete;

#pragma mark - overridden functions
+ (id)init {
	return [[self alloc] init];
}


+ (id)initWithButtons :(NSArray*)buttons {
	return [[self alloc] initWithButtons :buttons];
}

- (id)init {
    if (!(self = [super init]))
		return nil;
	
	return self;
}

- (id)initWithButtons :(NSArray*)buttons {
    if (!(self = [self init]))
		return nil;
	
	//CCLOG(@"initializing a ButtonGroup");
	[self addButtons:buttons];
	[self setLinearSequenceWithIsInReverse:0]; // default sequence
	
	return self;
}

- (void)addButton :(Button*)button { // could use variadic function
	[self addChild:button];
	[self setLinearSequenceWithIsInReverse:0];
}
 
- (void)addButtons :(NSArray*)buttons {
	for (int i = 0; i < buttons.count; i++) {
		[self addChild:[buttons objectAtIndex:i]];
	}
	[self setLinearSequenceWithIsInReverse:0];
}

- (void)onExit {
	//CCLOG(@"[ButtonGroup onExit]");
	[super onExit];
}

- (void)dealloc {
	//CCLOG(@"[ButtonGroup dealloc]");
	[super dealloc];
}

#pragma mark - public functions
// used in GameScreen
- (int)update {
	// check if buttons are being pressed in the correct sequence:
	// if button was pressed, check sequence
	// if last button pressed is correct, continue
	// if last button pressed is not correct, fail
	// if last button pressed is the last button in the sequence, success
	// reset button group
	// return 1 if successful, 0 if failure, -1 otherwise
	
	int enabledButtonsCount = [self enabledButtonCount]; //todo: sloppy
	int n;
	
	for (int i = 0; i < [[self children]count]; i++) {
		 
		// check buttons in reverse sequence
		if (sequenceIsInReverse)
			n = i;
		else
			n = [[self children]count] - 1 - i;
		
		Button *currentButton = (Button *)[self getChildByTag:n];
		
		if (currentButton.isEnabled && currentButton.isOn && !currentButton.sequenceWasChecked) {
			
			if (currentButton.positionInSequence != currentSequencePosition) {
				[self reset];
				return 0;
			}
			
			currentButton.sequenceWasChecked = YES;
			currentSequencePosition++;
			
			if (![athlete isStunned])
				[athlete liftLeg:currentButton.positionInSequence];
			
			// if last button was pressed, success!
			if (currentSequencePosition == enabledButtonsCount) {
				[self reset];
				return 1;
			}
			
			// todo: limit: checks button press every 1/60th of a second
			// code sequence of events: ccTouchBegan, turn button on, check sequence
			return -1;
		}
	}
	
	return -1;
}

- (int)onButtonCount {
	int n = 0;
	
	for (int i = 0; i < [[self children]count]; i++) {
		Button *currentButton = (Button *)[self getChildByTag:i];
		
		if (currentButton.isOn)
			n++;
	}
	
	return n;
}

- (int)enabledButtonCount {
	int n = 0;
	
	for (int i = 0; i < [[self children]count]; i++) {
		Button *currentButton = (Button *)[self getChildByTag:i];
		
		if (currentButton.isEnabled)
			n++;
	}
	
	return n;
}

- (void)setLinearSequenceWithIsInReverse :(BOOL)isInReverse {
	//set sequence
	int positionInSequence = 0;
	int n;
	
	for (int i = 0; i < [[self children]count]; i++) {
		
		if (isInReverse)
			n = [[self children]count] - 1 - i;
		else
			n = i;
		
		Button *currentButton = (Button *)[self getChildByTag:n];
		if (currentButton.isEnabled) {
			currentButton.positionInSequence = positionInSequence;
			positionInSequence++;
		}
	}
		
	currentSequencePosition = 0;
	
	sequenceIsInReverse = isInReverse;
}


/*
- (void)setRandomSequence {
	// shuffle array http://stackoverflow.com/questions/56648/whats-the-best-way-to-shuffle-an-nsmutablearray
	// fudge objective-c, just use C++ STL from now on!
	
	currentSequence = [[NSMutableArray alloc] init];
	
	for (int i = 0; i < [[self children]count]; i++) {
		NSNumber *n = [NSNumber numberWithInt:i];
		[currentSequence addObject :n];
	}
	
	[currentSequence shuffle];
	
	for (int i = 0; i < [[self children]count]; i++) {
		Button *currentButton = (Button *)[self getChildByTag:i];
		currentButton.positionInSequence = [[currentSequence objectAtIndex:i]intValue];
	}
}
*/

- (void)flash {
	for (int i = 0; i < [[self children]count]; i++) {
		Button *currentButton = (Button *)[self getChildByTag:i];
		if (currentButton.isEnabled)
			[currentButton flash];
	}
}

// todo: should add this back in while counting down
/*
- (void)flashSequence {
	for (int i = 0; i < [[self children]count]; i++) {
		int currentSequenceElement = [[currentSequence objectAtIndex:i]intValue];
		Button *currentButton = (Button *)[self getChildByTag:currentSequenceElement];
		[self runAction:[CCSequence actions:[CCDelayTime actionWithDuration:(0.75*i) + 0.75], 
		[CCCallFunc actionWithTarget:currentButton selector:@selector(flash)],
		nil]];
	}
}
*/

#pragma mark - private functions
- (void)reset {
	currentSequencePosition = 0;
	
	for (int i = 0; i < [[self children]count]; i++) {
		Button *currentButton = (Button *)[self getChildByTag:i];
		if (currentButton.isEnabled)
			[currentButton reset];
	}
}

#pragma mark - properties
- (BOOL)isEnabled {
	for (int i = 0; i < [[self children]count]; i++) {
		Button *currentButton = (Button *)[self getChildByTag:i];
		
		if (!currentButton.isEnabled)
			return NO;
	}
	
	return YES;
}

- (void)setIsEnabled :(BOOL)IsEnabled {	
	for (int i = 0; i < [[self children]count]; i++) {
		Button *currentButton = (Button *)[self getChildByTag:i];
		currentButton.isEnabled = IsEnabled;
	}
	
	[self reset];
}

@end
