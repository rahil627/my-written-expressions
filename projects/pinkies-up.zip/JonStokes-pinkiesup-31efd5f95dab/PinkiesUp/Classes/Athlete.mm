//
//  Athlete.m
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/22/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Athlete.h"
#import "Global.h"
#import "GameManager.h"

@implementation Athlete

@dynamic torsoX, linearVelocityX;
@synthesize torsoBody, world, size, isTop, isStunned;

#pragma mark - overridden functions
+ (id)init:(BOOL)isTop {
	return [[self alloc] init:isTop];
}

- (id) init:(BOOL) _isTop {
    if(!(self = [super init]))
		return nil;
	
	CCLOG(@"initializing a Harold");
	
	isTop = _isTop;
    
    world = [GameManager sharedGameManager].world;
	partSprites = [[NSMutableArray alloc] init];
    
    float spineLength = sqrtf(pow(10.5,2) + pow(10.5,2))*DEFAULT_HAROLD_SCALE * HAROLD_PIXEL_SCALE / PTM_RATIO;
    CCLOG(@"spineLength: %f", spineLength);
	
	//torso
    torso = [CCSprite spriteWithFile:@"harold_0009_1.png"];
    //torso.color = ccc3(170,255,102);
    torso.scale = DEFAULT_HAROLD_SCALE;
    [self addChild:torso z:0];
    torsoBody = (b2Body*)[self createBoxBodyForSprite:torso density:1.0f friction:0.3f restitution:0.1f damping:1.0f];  //original fric = 0.3, damp = 1.0f
	
	//parts
    NSString *partsString = @"harold_0008_2.png:harold_0007_3.png:harold_0006_4.png:harold_0005_5.png:harold_0004_6.png:harold_0003_7.png:harold_0003_8.png";
    [self addMidParts:partsString];
    
	head = [partSprites lastObject];
	followHead = NO;
	
    //todo: consider using the flood fill class for his eyes, HAROLD ANGRY!!
    CCSprite *leftEye = [CCSprite spriteWithFile:@"harold_0000_eye.png"];
    leftEye.tag = 0;
    leftEye.position = ccp(2.5*HAROLD_PIXEL_SCALE, 5.5*HAROLD_PIXEL_SCALE);
    [head addChild:leftEye];
    
    CCSprite *rightEye = [CCSprite spriteWithFile:@"harold_0000_eye.png"];
    rightEye.tag = 1;
    rightEye.position = ccp(5.5*HAROLD_PIXEL_SCALE, 5.5*HAROLD_PIXEL_SCALE);
    [head addChild:rightEye];
    
    CCSprite *mouth = [CCSprite spriteWithFile:@"harold_0001_mouth.png"];
    mouth.tag = 2;
    mouth.position = ccp(4.0*HAROLD_PIXEL_SCALE, 3.5*HAROLD_PIXEL_SCALE);
    [head addChild:mouth];
	
	[self colorParts];
	
	size = [torso boundingBox].size;
	
	stunTimer = 0.0f;
	isStunned = NO;
	
	[self scheduleUpdate];
	
	//[self headShakeNo];
	//[self headRotate];
	    
    return self;
}

- (void)dealloc {
	[super dealloc];
}

#pragma mark - public functions
- (void) transitionPartsHomePointsFromMaxX:(CGFloat)maxX toMinX:(CGFloat)minX {
	
	CGFloat d = maxX - minX;
	
	for(AthletePart *part in partSprites) {
		CGPoint hp = [self convertToWorldSpace:part.homePosition];
		
		if (hp.x >= maxX)
			hp.x -= d; // why is this working?
		else if (hp.x < minX)
			hp.x += d;
		
		part.homePosition = [self convertToNodeSpace:hp];
	}
}

- (void) transitionPartsPositionsFromMaxX:(CGFloat)maxX toMinX:(CGFloat)minX { // todo: combine with above function?
	
	CGFloat d = maxX - minX;
	
	for(AthletePart *part in partSprites) {
		if (part.opacity != 255/2) // todo: uncomment this when Harold is positioned after the buttons. Or if you just wanna have fun! =D
			return;
		
		CGPoint p = ccp(part.body->GetPosition().x * PTM_RATIO, part.body->GetPosition().y * PTM_RATIO);
		//CCLOG(@"p.x = %f, p.y = %f", p.x, p.y);
		
		if (p.x >= maxX)
			p.x -= d;
		else if (p.x < minX)
			p.x += d;
		
		part.body->SetTransform(b2Vec2(p.x / PTM_RATIO, part.body->GetPosition().y), part.body->GetAngle());
	}
}

- (void) setPosition2:(CGPoint)position { // overriding setPosition did bad things
	// teleport all of harold's parts!
	
	torsoBody->SetTransform(b2Vec2(position.x / PTM_RATIO, position.y / PTM_RATIO), 0);
	
	for(AthletePart *part in partSprites) {
		part.position = position;
		part.body->SetTransform(b2Vec2(position.x / PTM_RATIO, position.y / PTM_RATIO), 0);
		
	}
	
	//[super setPosition:position];
}

#pragma mark - public properties
- (float)torsoX {
	return torsoBody->GetPosition().x * PTM_RATIO;
}

- (void) setTorsoX:(float)x {
	torsoBody->SetTransform(b2Vec2(x / PTM_RATIO, torsoBody->GetPosition().y), torsoBody->GetAngle());
}

- (float)linearVelocityX {
	return torsoBody->GetLinearVelocity().x * PTM_RATIO;
}

- (void)setLinearVelocityX:(float)linearVelocityX {
	torsoBody->SetLinearVelocity(b2Vec2(linearVelocityX / PTM_RATIO, torsoBody->GetPosition().y));
}

#pragma mark private functions
- (b2Body *) createBoxBodyForSprite: (CCSprite*)sprite density:(float)density friction:(float)friction 
						restitution:(float)restitution damping:(float)damping {
    
    b2Body *body;
    b2BodyDef boxBodyDef;
    boxBodyDef.type = b2_dynamicBody;
    CGPoint worldPoint = [self convertToWorldSpace:sprite.position];
    boxBodyDef.position.Set(worldPoint.x/PTM_RATIO, worldPoint.y/PTM_RATIO); 
	
	if([sprite isKindOfClass:[AthletePart class]])
		boxBodyDef.userData = sprite;
	else 
		boxBodyDef.userData = self; //torso
    
	boxBodyDef.linearDamping = damping;  //adds air resistance to box
	boxBodyDef.angularDamping = 0.5f;
    body = world->CreateBody(&boxBodyDef);
        
    b2PolygonShape boxShape;
    float height = [sprite boundingBox].size.height/PTM_RATIO/2.0f;
	boxShape.SetAsBox(height, height);// SetAsBox uses the half width and height (extents)
	
	b2FixtureDef fixdef;
	fixdef.shape = &boxShape;
	fixdef.density = density;
	fixdef.friction = friction;
	fixdef.restitution = restitution;
	fixdef.filter.groupIndex = -1;  //todo: separate top athlete from bottom athlete, and use different groupIndeces
	body->CreateFixture(&fixdef);
    
    return body;
}

-(void) addMidParts: (NSString*) midParts {
    
    NSArray *partNames = [midParts componentsSeparatedByString:@":"];

    for(int i = 0; i < [partNames count]; ++i) {
        NSString *filename = [partNames objectAtIndex:i];
        AthletePart *part = [AthletePart spriteWithFile:filename];
		float fudge = 0.75f;  //not sure why I need this?
		if(isTop) {
			part.position = ccp(-HAROLD_PIXEL_SCALE*DEFAULT_HAROLD_SCALE*(i+1)*2.0f*fudge, 
								HAROLD_PIXEL_SCALE*DEFAULT_HAROLD_SCALE*(i+1)*2.0f*fudge);
		} else {
			part.position = ccp(HAROLD_PIXEL_SCALE*DEFAULT_HAROLD_SCALE*(i+1)*2.0f*fudge, 
								HAROLD_PIXEL_SCALE*DEFAULT_HAROLD_SCALE*(i+1)*2.0f*fudge);
		}
		part.homePosition = part.position;
		part.scale = DEFAULT_HAROLD_SCALE;
		part.followBody = YES;
		float density = 1.0f; //part.boundingBox.size.width/100.0f;

#define DEFAULT_PART_LINEAR_DAMPING 1.0f

		part.body = [self createBoxBodyForSprite:part 
										 density:density friction:0.8f restitution:0.1f damping:DEFAULT_PART_LINEAR_DAMPING];
		
		CCLOG(@"part pos: %@", NSStringFromCGPoint(part.position));
			  
        [self addChild:part z:1];
		[partSprites addObject:part];
		
    }
    
}

-(void) addLegs:(int) numLegs {
	
	if(!legs) {

		legs = [[NSMutableArray alloc] init];
		CGPoint leftmostLegPos, rightmostLegPos;
					
		leftmostLegPos = ccp(-7.0f*HAROLD_PIXEL_SCALE*DEFAULT_HAROLD_SCALE, -7.0f*HAROLD_PIXEL_SCALE*DEFAULT_HAROLD_SCALE);
		rightmostLegPos = ccp(7.0f*HAROLD_PIXEL_SCALE*DEFAULT_HAROLD_SCALE, -7.0f*HAROLD_PIXEL_SCALE*DEFAULT_HAROLD_SCALE);
		float legSpread = rightmostLegPos.x - leftmostLegPos.x;
		
		//distribute legs between leg positions
		for(int i = 0; i < numLegs; ++i) {
			
			CCSprite *leg = [CCSprite spriteWithFile:@"harold_0003_leg.png"];
			leg.color = torso.color;
			leg.scale = DEFAULT_HAROLD_SCALE;
			leg.position = ccp(leftmostLegPos.x + i*legSpread/(numLegs-1), leftmostLegPos.y);
			
			if(!isTop) {
				
				leg.anchorPoint = ccp(0.25,1); //middle top of leg
				
			} else {
				
				leg.anchorPoint = ccp(0.75,1); //middle top of leg
				leg.flipX = YES;
				
			}
			
			[self addChild:leg];
			[legs addObject:leg];
			
		}
		
	}

}

-(void) liftLeg:(int)legIdx {
	
	CCSprite *leg = [legs objectAtIndex:legIdx];
	
//	id rotateLeft = [CCRotateTo actionWithDuration:0.2f angle:45];
//	id rotateRight = [CCRotateTo actionWithDuration:0.2f angle:0];
//	id seq = [CCSequence actions:rotateLeft, rotateRight, nil];
//	[leg runAction:seq];
	
//	id rotateLeft = [CCRotateBy actionWithDuration:0.25f angle:360];
//	[leg runAction:rotateLeft];
	
	float dur = 0.4f;
	float imp = 10.0f;
	
	if(!isTop) {
	
		id rotateLeft = [CCSequence actions:[CCRotateTo actionWithDuration:dur/2.0f angle:180], [CCRotateTo actionWithDuration:dur/2.0f angle:360], nil];
		[leg runAction:rotateLeft];
		//torsoBody->ApplyLinearImpulse(b2Vec2(0, imp), torsoBody->GetPosition());

	} else {
		
		id rotateRight = [CCSequence actions:[CCRotateTo actionWithDuration:dur/2.0f angle:-180], [CCRotateTo actionWithDuration:dur/2.0f angle:-360], nil];
		[leg runAction:rotateRight];
		//torsoBody->ApplyLinearImpulse(b2Vec2(0, -imp), torsoBody->GetPosition());

	}
	
	if(!APPLY_IMPULSE_AT_SEQUENCE_FINISH) {
		
		torsoBody->ApplyLinearImpulse(b2Vec2(HAROLD_IMPULSE, 0.0f),torsoBody->GetPosition());

	}
}

-(void) colorParts {
	
	//torso to head colors
	torso.color = ccc3(216,27,101);
	
	NSString *partColorsString = @"204,68,204;40,68,224;69,176,255;168,255,255;0,204,85;238,238,119;170,255,102";
	NSArray *partColors = [partColorsString componentsSeparatedByString:@";"];
		
	for(int i = 0; i < [partSprites count]; ++i) {
		NSArray *colors = [[partColors objectAtIndex:i] componentsSeparatedByString:@","];
		CCSprite *spr = [partSprites objectAtIndex:i];
		spr.color = ccc3([[colors objectAtIndex:0] intValue], [[colors objectAtIndex:1] intValue], [[colors objectAtIndex:2] intValue]);
	
	}
	
	//color eyes and mouth
	for(CCSprite *spr2 in head.children)
		spr2.color = ccc3(204,68,204);
	
}

- (void) update:(ccTime) dt {
	
	//allow for body parts to follow head during animations like such as the famed harold ground head slap
	if(followHead) {
		head.homePosition = head.position;
		CGPoint headWorldPos = [self convertToWorldSpace:head.position];
		head.body->SetTransform(b2Vec2(headWorldPos.x/PTM_RATIO, headWorldPos.y/PTM_RATIO), CC_DEGREES_TO_RADIANS(head.rotation));
		
		//distribute home positions for parts along spine
		CGPoint d = ccpMult(head.position, 1/7.0f);  //current vector between parts
		for(int i = 0; i < [partSprites count]-1; ++i) {
			AthletePart *part = [partSprites objectAtIndex:i];
			part.homePosition = ccpMult(d, i+1.0f);
		}

	}
	
	for(AthletePart *part in partSprites) {
		
		//make parts always move towards home position	
		if(part.followBody) {
			// f = kx
			CGPoint homePosWorld = [self convertToWorldSpace:part.homePosition];
			b2Vec2 d = part.body->GetPosition() - b2Vec2(homePosWorld.x/PTM_RATIO, homePosWorld.y/PTM_RATIO);
			float l = d.Length();
			float k = -40.0f;
			part.body->ApplyForce(k*l*d, part.body->GetPosition());
		} else {
			
			if(isTop) {
				part.body->ApplyForce(b2Vec2(0.0f,-WORLD_GRAVITY), part.body->GetPosition());
				if(part.position.x > torso.position.x && part.canFollowBody) {
					part.followBody = YES;
					part.opacity = 255;
					part.body->SetLinearDamping(DEFAULT_PART_LINEAR_DAMPING);
				}
			} else {
				part.body->ApplyForce(b2Vec2(0.0f,WORLD_GRAVITY), part.body->GetPosition());
				if(part.position.x < torso.position.x && part.canFollowBody) {
					part.followBody = YES;
					part.opacity = 255;
					part.body->SetLinearDamping(DEFAULT_PART_LINEAR_DAMPING);
				}
			}
			
		}
		
	}
	
	// handle stun
	stunTimer -= dt;
	if (isStunned && stunTimer <= 0)
		[self unstun];
	isStunned = stunTimer > 0;
}

-(void) followHead {
	followHead = YES;
	
}

-(void) unfollowHead {
	followHead = NO;
	
}

-(void) headShakeNo {
	
	CGPoint home = head.position;
	
	id moveLeft = [CCMoveTo actionWithDuration:1.0f position:ccp(home.x - 30,home.y)];
	id moveRight = [CCMoveTo actionWithDuration:1.0f position:ccp(home.x + 30, home.y)];
	id seq = [CCSequence actions:moveLeft, moveRight, nil];
	id repeat = [CCRepeatForever actionWithAction:seq];
	[head runAction:repeat];
	
}

-(void) headRotate {
	
	id rotate = [CCRotateBy actionWithDuration:1.5f angle:360];
	id repeat = [CCRepeatForever actionWithAction:rotate];
	[head runAction:repeat];
}

-(void) stun {
	isStunned = YES;
	stunTimer = STUN_TIME;
	torsoBody->SetLinearVelocity(b2Vec2(0, 0));
	
	torso.opacity = 255/2;
	
	for(CCSprite *leg in legs)
		leg.opacity = 255/2;
	
	for(AthletePart *part in partSprites) {
	
		part.followBody = NO;
		part.canFollowBody = NO;
		part.opacity = 255/2;
		part.body->SetLinearDamping(0.1f);
	
	}
	
	// or SAD FACE
}

-(void) unstun {
	isStunned = NO;
	
	torso.opacity = 255;
	
	for(CCSprite *leg in legs)
		leg.opacity = 255;
	
	for(AthletePart *part in partSprites) {
		part.canFollowBody = YES;
	}

}

@end
