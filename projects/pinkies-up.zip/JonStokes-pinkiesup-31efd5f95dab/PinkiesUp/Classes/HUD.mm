//
//  HUD.m
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/18/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "HUD.h"
#import "Global.h"
#import "GameManager.h"

@implementation HUD

@synthesize beginningOfLineX;

#pragma mark - overridden functions
+ (id)init {
	return [[self alloc] init];
}

- (id)init {
    if (!(self = [super init]))
		return nil;
	
	CCLOG(@"initializing a HUD");
	
	CGSize s = [CCDirector sharedDirector].winSize;
	
	// add line
	line = [CCSprite spriteWithFile:@"Line.png"];
	line.position = ccp(s.width / 2, s.height / 2);
	[self addChild:line];
	
	/*
	// add score label
	scoreLabel = [CCLabelTTF labelWithString:@"0" fontName:@"Marker Felt" fontSize:64];
	scoreLabel.position = ccp(s.width / 2 - scoreLabel.contentSize.width / 2, s.height / 2 - scoreLabel.contentSize.width / 2);
	[self addChild:scoreLabel]; //todo: temp
	*/
	
	// add lap marks
	int lapCount = [[GameManager sharedGameManager] lapCount];
	CGFloat lineLength = line.textureRect.size.width;
	CGFloat beginningOfLine = line.position.x - lineLength / 2;
	
	CCSprite* lapMark;
	lapMark = [CCSprite spriteWithFile:@"LapMark.png"];
	for (int i = 0; i <= lapCount; i++) {
		lapMark = [CCSprite spriteWithFile:@"LapMark.png"];
		lapMark.position = ccp(beginningOfLine + i * (lineLength / lapCount), line.position.y);
		[self addChild:lapMark];
	}
	
	// add player icons
	playerIconTop = [CCSprite spriteWithFile:@"PlayerIcon.png"];
	//playerIconTop.position = ccp(s.width * 3 / 20, s.height / 2);
	playerIconTop.position = ccp(-50, s.height / 2);
	[self addChild:playerIconTop];
	
	playerIconBottom = [CCSprite spriteWithFile:@"PlayerIcon.png"];
	//playerIconBottom.position = ccp(s.width * 3 / 20, s.height/2);
	playerIconBottom.position = ccp(-50, s.height/2);
	[self addChild:playerIconBottom];
	
	// set some things for public access
	beginningOfLineX = beginningOfLine;
	
    return self;
}

- (void)dealloc {
	[super dealloc];
}
 
#pragma mark - public functions
- (void)updateWithTopTeamDistance :(CGFloat)topTeamDistance bottomTeamDistance:(CGFloat)bottomTeamDistance {
	CGFloat lineLength = line.textureRect.size.width;
	CGFloat beginningOfLine = line.position.x - lineLength / 2;
	
	playerIconTop.position = ccp(beginningOfLine + topTeamDistance * lineLength, playerIconTop.position.y);
	playerIconBottom.position = ccp(beginningOfLine + bottomTeamDistance * lineLength, playerIconBottom.position.y);
}

#pragma mark - properties
/*
- (void)setScore :(int)integer {
    scoreLabel.string = [NSString stringWithFormat:@"%d", integer];
}

- (int)score {
	return [scoreLabel.string intValue];
}
*/
@end
