/*
 
 File: DevicesManager.h
 Abstract: Contains a list of devices.
 Version: 1.0

 */

#import "Device.h"

@interface DevicesManager : NSObject {
	NSMutableArray *devices; // contains available and connected devices, not including self
}

- (void)addDevice:(Device *)device;
- (void)removeDevice:(Device *)device;
- (Device *)deviceWithID:(NSString *)peerID;

@property (nonatomic, readonly) NSArray *sortedDevices;

@end
