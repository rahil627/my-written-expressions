//
//  Athlete.h
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/22/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Box2D.h"
#import "Global.h"
#import "AthletePart.h"
#import "Team.h"

/** the main character sprite */
@interface Athlete : CCNode {
    CCSprite *torso;
    b2Body *torsoBody;
    b2World* world;
    AthletePart *head;
	NSMutableArray *partSprites; // includes head, which is the last element
	CGSize size;
	BOOL followHead;
	BOOL isTop;
	NSMutableArray *legs;
	CGFloat stunTimer;
	BOOL isStunned;
}

@property (nonatomic, readwrite) b2World *world;
@property (nonatomic, readwrite) b2Body *torsoBody;
@property (nonatomic, readwrite) CGSize size;
@property (nonatomic, readwrite) BOOL isTop;
@property (nonatomic, readwrite) BOOL isStunned;

+ (id)init:(BOOL)isTop;
- (id)init:(BOOL)isTop;
- (void)dealloc;
- (void)setPosition2:(CGPoint)position;
- (void)addLegs:(int)numLegs;
- (void)liftLeg:(int)legIdx;
- (void)stun;

// convenience functions for Rahil because he doesn't know Box2d too well :(
@property (nonatomic, readwrite) float torsoX; // no instance variable
@property (nonatomic, readwrite) float linearVelocityX; // no instance variable
- (void) transitionPartsHomePointsFromMaxX:(CGFloat)maxX toMinX:(CGFloat)minX;
- (void) transitionPartsPositionsFromMaxX:(CGFloat)maxX toMinX:(CGFloat)minX; // todo: this needs some help!

@end
