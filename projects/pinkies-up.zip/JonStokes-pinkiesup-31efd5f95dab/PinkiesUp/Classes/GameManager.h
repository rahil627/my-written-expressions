//  GameManager.h
//  cake
//
//  Created by Jon Stokes on 7/6/11.
//  Copyright 2011 Jon Stokes. All rights reserved.
//
// adapted from Ray Wenderlich and Rod Strougo's code on p174 of "Learning Cocos2d"

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Box2D.h"

@class ButtonGroup;
@class SessionManager;
@class DataHandler;
@class DevicesManager;

// odd numbers are server datatypes, even numbers are corresponding client datatypes
// todo: rename messages to server to, kClientIsReady, kTopAthleteReachedEndOfDevice
typedef enum {
	kEmpty,
	kAddTopAthleteToNextDevice, // to server
	kAddTopAthlete, // to client
	kAddBottomAthleteToNextDevice,
	kAddBottomAthlete,
	kEndGameToAllDevices,
	kEndGame,
	kStartGameToAllDevices, // used only by server, not needed, but used for consistency
	kStartGame,
	kIncreaseReadyCountToServer,
	kIncreaseReadyCount, // used only by server
	kDecreaseReadyCountToServer,
	kDecreaseReadyCount, // used only by server
	kResetGameToAllDevices, // never used
	kResetGame,
	kSendDeviceSequencePositionToServer, // used only by server
	kSendDeviceSequencePosition
} DataType;

@interface GameManager : NSObject {
	// game related
	b2World *world;
    CGSize screenSize;
	int topButtonCount;
	int bottomButtonCount;
	int topTeamScore;
	int bottomTeamScore;
	int lapCount;
	
	// variables created for iPhone compatibility
	ccResolutionType resolutionType;
	CGFloat buttonWidth;
	CGFloat buttonHeight;
	CGFloat groundHeight;
	CGFloat trackLength;
	CGFloat trackBegin;
	CGFloat trackEnd;
	
	// networking // todo: this is getting unwieldy, create NetworkManager
	SessionManager* sessionManager;
	DataHandler* dataHandler;
	DevicesManager* devicesManager;
	BOOL isMultiplayer;
	BOOL isServer;
	int dataToSend;
	int dataReceived;
	int topAthleteDevicePosition;
	int bottomAthleteDevicePosition;
	int deviceSequencePosition; // -1 for server, 0 for first client, which matches the array indices of the device array
	
	// additional data to send // todo: could create structs for each type of packet
	int integerToSend;
	int integerToReceive;
}

@property (readwrite) b2World *world;
@property (nonatomic, readwrite) CGSize screenSize;
@property (nonatomic, readwrite) int topButtonCount;
@property (nonatomic, readwrite) int bottomButtonCount;
@property (nonatomic, readwrite) int topTeamScore;
@property (nonatomic, readwrite) int bottomTeamScore;
@property (nonatomic, readwrite) int lapCount;

@property (nonatomic, readonly) ccResolutionType resolutionType;
@property (nonatomic, readwrite) CGFloat buttonWidth;
@property (nonatomic, readwrite) CGFloat buttonHeight;
@property (nonatomic, readwrite) CGFloat groundHeight;
@property (nonatomic, readwrite) CGFloat trackLength;
@property (nonatomic, readwrite) CGFloat trackBegin;
@property (nonatomic, readwrite) CGFloat trackEnd;

@property (nonatomic, readwrite, assign) SessionManager* sessionManager; // todo: might be different for delegates, atomic?
@property (nonatomic, readwrite, assign) DataHandler* dataHandler;
@property (nonatomic, readwrite, assign) DevicesManager* devicesManager;
@property (nonatomic, readwrite) BOOL isMultiplayer; // can use this to check if the session initialized too
@property (nonatomic, readwrite) BOOL isServer;
@property (nonatomic, readwrite) int dataToSend;
@property (nonatomic, readwrite) int dataReceived;
@property (nonatomic, readwrite) int topAthleteDevicePosition;
@property (nonatomic, readwrite) int bottomAthleteDevicePosition;
@property (nonatomic, readonly) int deviceCount; // no instance variable
@property (nonatomic, readwrite) int deviceSequencePosition;
@property (nonatomic, readwrite) int integerToSend;
@property (nonatomic, readwrite) int integerToReceive;
@property (nonatomic, readwrite) float floatToSend;
@property (nonatomic, readwrite) float floatToReceive;

+ (GameManager*)sharedGameManager;

// i didn't know where else to put this, used in two scenes
- (NSArray*)createButtonsWithIsTop :(BOOL)isTop isReadyScreen:(BOOL)isReadyScreen buttonCount:(int)buttonCount deviceSequencePosition:(int)deviceSequencePosition;

// networking
- (void)startSessionWithIsServer:(BOOL)isServer;
- (void)endSession;
- (void)connectToServer;
- (void)disconnect;
- (void)sendData:(int)data;
- (void)dataWasReceived:(int)data;

@end
