//
//  Button.h
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/18/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import <vector>

@interface Button : CCSprite <CCTargetedTouchDelegate> {
	// public
	BOOL isEnabled;
	BOOL canTurnOff;
	ccColor4F color2; // color is taken by CCSprite and overriding it does bad things
	int positionInSequence;
	BOOL sequenceWasChecked;
	
	// readonly
	BOOL isPressed;
	BOOL isOn;
	
	// private
	std::vector<CGPoint> verticesVector;
	std::vector<float> triangleVertices;
	CGFloat flashAlpha;
	BOOL isFlashing;
}

@property(nonatomic, readonly) BOOL isPressed;
@property(nonatomic, readonly) BOOL isOn;
@property(nonatomic, readwrite) BOOL isEnabled;
@property(nonatomic, readwrite) BOOL canTurnOff;
@property(nonatomic, readwrite) int positionInSequence;
@property(nonatomic, readwrite) BOOL sequenceWasChecked;
@property(nonatomic, readwrite) ccColor4F color2;

+ (id)initWithVertices:(NSMutableArray*)vertices;
- (id)initWithVertices:(NSMutableArray*)vertices;
- (void)dealloc;
- (void)reset;
- (void)flash;
- (BOOL)isEnabled;
- (void)setIsEnabled :(BOOL)_isEnabled;

@end
