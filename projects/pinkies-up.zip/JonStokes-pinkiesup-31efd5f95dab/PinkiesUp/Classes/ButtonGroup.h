//
//  ButtonGroup.h
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/19/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class Button;
@class Athlete;

/** contains buttons and group functions */
@interface ButtonGroup : CCNode {
	int currentSequencePosition;
	//NSMutableArray *currentSequence;
	BOOL sequenceIsInReverse;
	Athlete *athlete;
}

@property (nonatomic, readwrite, assign) Athlete *athlete;
@property (nonatomic, readwrite, assign) BOOL isEnabled; // no instance variable

+ (id)init;
+ (id)initWithButtons :(NSArray*)buttons;
- (id)init;
- (id)initWithButtons :(NSArray*)buttons;
- (void)dealloc;
- (void)addButton :(Button*)button;
- (void)addButtons :(NSArray*)buttons;
// returns 1 upon successful sequence, 0 upon failed sequence, and -1 otherwise
- (int)update;
- (void)reset;
- (void)flash;
//- (void)flashSequence;
- (int)onButtonCount;
- (int)enabledButtonCount;
- (BOOL)isEnabled;
- (void)setIsEnabled :(BOOL)IsEnabled;
- (void)setLinearSequenceWithIsInReverse :(BOOL)isInReverse; // todo: reverse not used

@end
