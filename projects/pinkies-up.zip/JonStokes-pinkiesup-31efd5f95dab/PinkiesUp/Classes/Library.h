//
//  Library.h
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/23/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#include <vector>

/** static class that holds common variables and functions in Obj-C */
@interface Library : NSObject {

}

/**
 * checks if a point is in a polygon
 * works for concave and convex polygons
 * @param nvert - number of verticies
 * @param vertx - array containing x verticies
 * @param verty - array containing y verticies
 * @param testx - x value of point to test
 * @param testy - y value of point to test
 * @return not sure, hoping 0 or 1
 * @source http://stackoverflow.com/questions/217578/point-in-polygon-aka-hit-test
 */
+ (int)IsPointInPolygonWithVector :(const std::vector<CGPoint> &)vert :(int)nvert :(float)testx :(float)testy;

/** draw 2d triangles using OpenGL */
+ (void)drawTrianglesWithVertices:(const std::vector<float> &)v;

/** show an UIAlertView */
+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)message cancelButtonTitle:(NSString *)cancelButtonTitle;

/** default UIAlertView */
+ (void)showErrorAlertWithMessage:(NSString *)messsage;

@end

