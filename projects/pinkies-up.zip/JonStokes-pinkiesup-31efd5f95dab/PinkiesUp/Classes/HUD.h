//
//  HUD.h
//  Pinkies-Up
//
//  Created by Rahil Patel on 4/18/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

/** This class should display the same data for all devices */
@interface HUD : CCNode {
	//CCLabelTTF *scoreLabel;
	CCSprite *line;
	CCSprite *playerIconTop;
	CCSprite *playerIconBottom;
	
	CGFloat beginningOfLineX;
}

@property (nonatomic, readwrite) CGFloat beginningOfLineX;
//@property (nonatomic, readwrite) int score;

+ (id)init;
- (id)init;
- (void)updateWithTopTeamDistance :(CGFloat)topTeamDistance bottomTeamDistance:(CGFloat)bottomTeamDistance;
//- (int)score;
//- (void)setScore :(int)integer;
	
@end
