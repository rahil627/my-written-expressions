#import "DataHandler.h"

@interface PinkiesUpDataHandler : DataHandler {

}

@end
