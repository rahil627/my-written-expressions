//  GameManager.m
//  cake
//
//  Created by Jon Stokes on 7/6/11.
//  Copyright 2011 Jon Stokes. All rights reserved.
//
// adapted from Ray Wenderlich and Rod Strougo's code on p174 of "Learning Cocos2d"

#import "GameManager.h"
#import "Global.h"
#import "Library.h"
#import "Button.h"
#import <vector>

#import "SessionManager.h"
#import "DataHandler.h"
#import "DataProvider.h"
#import "DevicesManager.h"
#import "PinkiesUpDataProvider.h"
#import "NetworkingConstants.h"

using namespace std;

@interface GameManager (Private)
// readonly variables
	@property(nonatomic, readwrite) ccResolutionType resolutionType;
@end

@implementation GameManager

//static const float IPAD_BUTTON_WIDTH_FACTOR = 1;
//static const float IPAD_BUTTON_HEIGHT_FACTOR = 1;
//static const float IPHONE_BUTTON_WIDTH_FACTOR = 1;
//static const float IPHONE_BUTTON_HEIGHT_FACTOR = 1; 

static GameManager* _sharedGameManager = nil;

@dynamic resolutionType, deviceCount;
@synthesize world, screenSize, topButtonCount, bottomButtonCount, topTeamScore, bottomTeamScore, lapCount;
@synthesize buttonWidth, buttonHeight, groundHeight, trackLength, trackBegin, trackEnd;
@synthesize isMultiplayer, sessionManager, dataHandler, devicesManager, isServer, dataToSend, dataReceived, topAthleteDevicePosition, bottomAthleteDevicePosition, deviceSequencePosition,
integerToSend, integerToReceive, floatToSend, floatToReceive;

+(GameManager*)sharedGameManager 
{
    @synchronized([GameManager class])                             
    {
        if(!_sharedGameManager)                                    
            [[self alloc] init]; // inits the first time this function is called?
		
        return _sharedGameManager;                                
    }
    return nil; 
}

#pragma mark - overridden methods
+(id)alloc 
{
    @synchronized ([GameManager class])                          
    {
        NSAssert(_sharedGameManager == nil, @"Attempted to allocated a second instance of the Game Manager singleton");
        _sharedGameManager = [super alloc];
        return _sharedGameManager;                                
    }
    return nil;  
}

-(id)init {
	if (!(self = [super init]))
		return nil;
		
	// Game Manager initialized
	CCLOG(@"Game Manager Singleton, init");
	
	topButtonCount = 5;
	bottomButtonCount = 5;
	topTeamScore = 0;
	bottomTeamScore = 0;
	lapCount = LAPS;
	
	trackLength = 0;
	buttonWidth = 0;
	buttonHeight = 0;
	groundHeight = 0;
	trackLength = 0;
	trackBegin = 0;
	trackEnd = 0;
	
	// networking stuff
	devicesManager = [[DevicesManager alloc] init]; // retaining via retain property
	NSObject<DataProvider>* dataProvider = [[PinkiesUpDataProvider alloc] init];
	//pinkiesUpDataProvider = [[PinkiesUpDataProvider alloc] init];
	//NSObject<DataProvider>* dataProvider = pinkiesUpDataProvider;
	dataHandler = [[DataHandler alloc] initWithDataProvider:dataProvider devicesManager:devicesManager];
	//self.sessionManager = [[SessionManager alloc] initWithDataHandler:dataHandler devicesManager:devicesManager];
	//sessionManager = nil;
	
	// notifications being called from the SessionManager
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceWasConnected:) name:NOTIFICATION_DEVICE_CONNECTED object:nil];
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceWasDisconnected:) name:NOTIFICATION_THIS_DEVICE_DISCONNECTED object:nil];
	
	isMultiplayer = NO;
	dataReceived = 0;
	dataToSend = 0;
	topAthleteDevicePosition = -1; // remember to copy to resetNetworkingVariables if necessary
	bottomAthleteDevicePosition = -1;
	deviceSequencePosition = -1;
	integerToSend = -1;
	integerToReceive = -1;
	
	//[self setResolutionType];
	
    return self;
}

- (void)dealloc {
    [devicesManager release];
	[dataHandler release];
	[sessionManager release];
    [super dealloc];
}

//#pragma mark - public properties
//-(ccResolutionType)resolutionType {
//	return resolutionType;
//}
//
//-(void)setResolutionType {
//	// taken from ccFileUtils
//	ccResolutionType rt = kCCResolutionUnknown;
//    
//	// iPad?
//	if( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
//		// Retina Display?
//		if( CC_CONTENT_SCALE_FACTOR() == 2 )
//			rt = kCCResolutioniPadRetinaDisplay;
//		else
//			rt = kCCResolutioniPad;	
//	}
//	// iPhone?
//	else {
//		// Retina Display?
//		if( CC_CONTENT_SCALE_FACTOR() == 2 )
//			rt = kCCResolutioniPhoneRetinaDisplay;
//		else
//			rt = kCCResolutioniPhone;
//	}
//    
//	resolutionType = rt;
//}

#pragma mark - networking related stuff
#pragma mark public functions
- (void)startSessionWithIsServer:(BOOL)isServer {
	
	// remove session if it exists
	[self endSession];
	
	// create a new session, todo: a good place to use a retain property
	if (isServer)
		sessionManager = [[SessionManager alloc] initWithDataHandler:dataHandler devicesManager:devicesManager sessionMode:GKSessionModeServer];
	else
		sessionManager = [[SessionManager alloc] initWithDataHandler:dataHandler devicesManager:devicesManager sessionMode:GKSessionModeClient];
	
	[sessionManager start];
}

- (void)endSession {
	if (sessionManager != nil) {
		[sessionManager release];
		sessionManager = nil;
	}
}

- (void)connectToServer {
	if ([devicesManager.sortedDevices count] <= 0) { // only clients can see servers, not the other way around
		[Library showErrorAlertWithMessage:@"No hosts are available."];
		return;
	}
	
	Device *device = ((Device *) [devicesManager.sortedDevices objectAtIndex:0]); // should only be connected to one server
	[dataHandler connectToDevice:device];
}

- (void)disconnect {
	[sessionManager disconnectFromAllDevices];
}

- (int)deviceCount {
	return [devicesManager.sortedDevices count];
}

// use this to send data
- (void)sendData:(int)data {
	CCLOG(@"GameManager sendData dataType:%i", data);
	
	// if data is for the server, and this is the server, set it to received
	BOOL isServerData = (data % 2 == 1);
	
	if (isServer && isServerData) {
		[self dataWasReceived:data];
		return;
	}
	
	// if data is for a client, send to server
	dataToSend = data;
	
	if ([devicesManager.sortedDevices count] > 0) {
		Device *device = ((Device *)[devicesManager.sortedDevices objectAtIndex:0]);
		[dataHandler sendToDevice:device];
	}
	
	// todo: set to kEmpty upon success? probably should be handled in PinkiesUpDataProvider. Note sending to all.
	
}

// use this to send data from the server to a specific device
- (void)sendDataToDevice:(int)data deviceIndex:(int)deviceIndex {
	CCLOG(@"GameManager sendDataToDevice dataType:%i", data);
	
	BOOL isServerData = (data % 2 == 1);
	
	if (!isServer || isServerData) {
		CCLOGERROR(@"sendDataToDevice only a server should be sending client data");
		return;
	}
	
	// send data to a specific device
	dataToSend = data;
	
	if ([devicesManager.sortedDevices count] > 0) { // todo: uhhh, == 0 ?
		CCLOGERROR(@"sendDataToDevice not connected to any devices");
		return;
	}
	
	Device *device = ((Device *)[devicesManager.sortedDevices objectAtIndex:deviceIndex]);
	[dataHandler sendToDevice:device];
}

#pragma mark event handlers
// called when data is received
// when a data is recieved, the data may be handled here or in a particular scene (during the next frame)
// if the data is for the server, the server simply store it (readyCount) or relay the data to another client (addHaroldToNextDevice)
// todo: need to seperate client and server logic more, this is ridiculous
- (void)dataWasReceived:(int)data {
	CCLOG(@"GameManager dataWasReceived dataType:%i", data);
	
	dataReceived = data;
	
	if (data == kEmpty) {
		CCLOGERROR(@"GameManager dataWasReceived error: dataType = kEmpty");
		return;
	}
	
	// if the data can be handled by the GameManager, handle it
	if ([self handleReceivedClientData])
		return;
	
	// if it's client data, do nothing, it will be handled the corresponding scene
	BOOL isClientData = (data % 2 == 0);
	
	if (isClientData) {
		CCLOG(@"GameManager dataWasReceived this data is for the client");
		return;
	}
	
	// relay or handle server data
	CCLOG(@"GameManager dataWasReceived this data is for the server");
	
	Device* device;
	
	switch (data) {
		case kAddTopAthleteToNextDevice:
			// if is last device, end game
			if (topAthleteDevicePosition == [devicesManager.sortedDevices count] - 1) {
				dataToSend = kEndGame;
				[sessionManager sendToAllDevices];
				
				dataReceived = kEndGame; // tell server to end game too
				break;
			}
			
			// send kAddTopAthlete to the next device
			dataToSend = kAddTopAthlete;
			CCLOG(@"float to send: %f", [[GameManager sharedGameManager] floatToReceive]);
			floatToSend = floatToReceive;
			device = ((Device *)[devicesManager.sortedDevices objectAtIndex:topAthleteDevicePosition + 1]); // 0 is first client or second device
			[dataHandler sendToDevice:device];
			topAthleteDevicePosition++;
			
			dataReceived = kEmpty;
			break;
			
		case kAddBottomAthleteToNextDevice:
			// if is last device, end game
			if (bottomAthleteDevicePosition == [devicesManager.sortedDevices count] - 1) { // devicePosition starts at -1, count starts at 1, but need to count the server
				dataToSend = kEndGame;
				device = ((Device *)[devicesManager.sortedDevices objectAtIndex:0]);
				[sessionManager sendToAllDevices];
				
				dataReceived = kEndGame;
				break;
			}
			
			// send kAddBottomAthlete to the next device
			dataToSend = kAddBottomAthlete;
			CCLOG(@"float to send: %f", [[GameManager sharedGameManager] floatToReceive]);
			floatToSend = floatToReceive;
			device = ((Device *)[devicesManager.sortedDevices objectAtIndex:bottomAthleteDevicePosition + 1]);
			[dataHandler sendToDevice:device];
			bottomAthleteDevicePosition++;
			
			dataReceived = kEmpty;
			break;
			
		case kEndGameToAllDevices:
			dataToSend = kEndGame;
			[sessionManager sendToAllDevices];
			
			dataReceived = kEndGame; // tell server to end game too
			break;
			
		case kStartGameToAllDevices:
			dataToSend = kStartGame;
			[sessionManager sendToAllDevices];
			
			[self resetNetworkingVariables];
			dataReceived = kStartGame;
			break;
			
		case kIncreaseReadyCountToServer:
			// handled in ready screen
			dataReceived = kIncreaseReadyCount;
			break;
			
		case kDecreaseReadyCountToServer:
			dataReceived = kDecreaseReadyCount;
			break;
			
		case kSendDeviceSequencePositionToServer: // todo: need to send this before going to ready screen
			dataToSend = kSendDeviceSequencePosition;
			
			for (int i = 0; i < [[devicesManager sortedDevices] count]; i++) {
				integerToSend = i;
				[self sendData:kSendDeviceSequencePosition]; // todo: not sure if it's possible to send data multiple times
			}
			
			deviceSequencePosition = -1; // server
			dataReceived = kEmpty;
			break;
			
			
		default:
			CCLOGERROR(@"GameManager dataWasReceived bad dataType");
			break;
	}
	
}

// called in dataWasReceived
// returns true if the data was handled
- (BOOL)handleReceivedClientData {
	// handle game related client networking data here
	
	switch (dataReceived) {	
		case kSendDeviceSequencePosition:
			deviceSequencePosition = integerToReceive;
			dataReceived = kEmpty;
			CCLOG(@"GameManager handleReceivedClientData handled the data");
			return YES;
			break;
			
		default:
			CCLOG(@"GameManager handleReceivedClientData did not handle it");
			return NO;
			break;
	}
}

// called when any device was connected to the session
- (void)deviceWasConnected:(NSNotification*)notification {
	CCLOG(@"GameManager deviceWasConnected");
	
	// todo: called twice on both devices using GKPeerState notification
	// called twice on client device using this device notifcation
	
	if (isServer) { // todo: i think the server and client get this notification
		[self dataWasReceived:kSendDeviceSequencePositionToServer]; // todo: also add to deviceDisconnected?
	}
}

// called when any device is disconnected from the session
- (void)deviceWasDisconnected:(NSNotification *)notification { // todo: still runs two times on the client and three times on the server
	CCLOG(@"GameManager deviceWasDisconnected");
	
	// reset game due to disconnect
	
	// if this device was disconnected go to main menu
	[self dataWasReceived:kResetGame];
	
	// todo: else all other devices go to ready screen
	// kind of difficult to implement, worry later:
	// get peerID from notification
	// if not server
	// if peerID == thisDevicePeerID, go to main menu
	// else go to ready screen
	
	// not sure how to tell how a server disconnected
	
	// todo: handle this better later, adjust sequence accordingly
}

// i have a feeling this will grow
- (void)resetNetworkingVariables {
	topAthleteDevicePosition = -1;
	bottomAthleteDevicePosition = -1;
	deviceSequencePosition = -1;
}

#pragma mark - create button related stuff
#pragma mark public functions
- (NSArray*)createButtonsWithIsTop :(BOOL)isTop isReadyScreen:(BOOL)isReadyScreen buttonCount:(int)buttonCount deviceSequencePosition:(int)deviceSequencePosition {
	
	// create vertices
	NSMutableArray* bottomButtonGroupVertices = [self createBottomButtonGroupVerticesWithButtonCount:buttonCount];
	
	// create colors
	ccColor3B colorPalette[5];
	[self setColorPaletteWithDeviceSequencePosition:deviceSequencePosition colorPalette:colorPalette];
	ccColor3B invertedColorPalette[5] = { colorPalette[4], colorPalette[3], colorPalette[2], colorPalette[1], colorPalette[0] };
	vector<ccColor3B> colors = [self createColorsWithButtonCount:buttonCount colorPalette:isTop ? invertedColorPalette : colorPalette];
	
	// create the buttons
	NSMutableArray *buttons = [NSMutableArray array];
	NSMutableArray *topButtonVertices; // not autorelease
	Button* button;
	
	for (int i = 0; i < buttonCount; i++) {
		if (isTop) {
			// reflect the bottom verticies to create the top vertices
			topButtonVertices = [[NSMutableArray alloc] initWithArray:[bottomButtonGroupVertices objectAtIndex:i]];
			[self reflectPoints:topButtonVertices];
			button = [Button initWithVertices:topButtonVertices];
			
			[topButtonVertices release];
		}
		else {
			button = [Button initWithVertices:[bottomButtonGroupVertices objectAtIndex:i]];
		}
		
		button.tag = i;
		button.color2 = ccc4FFromccc3B(colors[i]);
		
		if (!isReadyScreen)
			button.canTurnOff = NO;
		
		[buttons addObject:button];
	}
	
	return buttons; // magical NSMutableArray ot NSArray conversion
}

#pragma mark private functions

// create vertices
// buttons, from left to right
// vertices, beginning polygon from top left point and going clockwise
// vertices using screen coordinates
- (NSMutableArray*)createBottomButtonGroupVerticesWithButtonCount:(int)buttonCount {
	CGSize s = [CCDirector sharedDirector].winSize;
	CGFloat sw = s.width;
	CGFloat sh = s.height;
	
	CGFloat bw = IS_IPAD ? (sw / 10) * IPAD_BUTTON_WIDTH_FACTOR : (sw / 10) * IPHONE_BUTTON_WIDTH_FACTOR;
	CGFloat bh = IS_IPAD ? (sh / 10) * IPHONE_BUTTON_WIDTH_FACTOR : (sh / 10) * IPHONE_BUTTON_HEIGHT_FACTOR;
	
	buttonWidth = bw; // todo: move this out
	buttonHeight = bh;
	
	CGFloat ow = sw / 20; // offset to transform squares into cool quadrilaterals
	CGFloat oh = sh / 10;
	
	// create button vertices for each set of buttons, depending on number of buttons
	// have to use dynamic arrays (C++ vector or NSMutableArray) because the number of verticies may differ
	// could not use NSMutableArray because it can not store non objective-c objects
	// could use NSValue to store CGPoint temporarily
	// may be better to use C++ vector, might even possible to create vector from array
	
	// test create
	
	// create vertex arrays
	// keep C-arrays for readability
	
	CGPoint b5[5][4] = { // currently set in a different way from the others
		{ ccp(0, 0), ccp(bw, bh), ccp(bw, sh / 2), ccp(0, sh / 2) },
		{ ccp(0, 0), ccp(sw / 3, 0), ccp(sw / 3 + bw, bh), ccp(bw, bh) },
		{ ccp(sw / 3, 0), ccp(sw * 2 / 3, 0), ccp(sw * 2 / 3 - bw, bh), ccp(sw / 3 + bw, bh) },
		{ ccp(sw * 2 / 3, 0), ccp(sw, 0), ccp(sw - bw, bh), ccp(sw * 2 / 3 - bw, bh) },
		{ ccp(sw - bw, bh), ccp(sw, 0), ccp(sw, sh / 2), ccp(sw - bw, sh / 2) }
	};
	
	CGPoint b4[4][6] = {
		{ ccp(0, sh/2), ccp(bw, sh/2), ccp(bw, bh), ccp(bw + sw/16 + ow, bh), ccp(bw + sw/16 - ow, 0), ccp(0,0)},
		{ ccp(bw + sw/16 + ow, bh), ccp(sw/2, bh), ccp(sw/2, 0), ccp(bw + sw/16 - ow, 0), ccp(9,9), ccp(9,9)},
		{ ccp(sw/2, bh), ccp(sw - bw - sw/16 - ow, bh), ccp(sw - bw - sw/16 + ow, 0), ccp(sw/2, 0), ccp(9,9), ccp(9,9)},
		{ ccp(sw - bw - sw/16 - ow, bh), ccp(sw - bw, bh), ccp(sw - bw, sh/2), ccp(sw, sh/2), ccp(sw, 0), ccp(sw - bw - sw/16 + ow , 0)}
	};
	
	CGPoint b3[3][6] = {
		{ ccp(0, sh/2), ccp(bw, sh/2), ccp(bw, bh), ccp(bw + sw/5 + ow, bh), ccp(bw + sw/5 - ow, 0), ccp(0,0)},
		{ ccp(bw + sw/5 + ow, bh), ccp(sw - bw - sw/5 - ow, bh), ccp(sw - bw - sw/5 + ow, 0), ccp(bw + sw/5 - ow, 0), ccp(9,9), ccp(9,9)},
		{ ccp(sw - bw - sw/5 - ow, bh), ccp(sw - bw, bh), ccp(sw - bw, sh/2), ccp(sw, sh/2), ccp(sw, 0), ccp(sw - bw - sw/5 + ow , 0)}
	};
	
	CGPoint b2[2][6] = {
		{ ccp(0, sh/2), ccp(bw, sh/2), ccp(bw, bh), ccp(sw/2 - ow, bh), ccp(sw/2 + ow, 0), ccp(0, 0)},
		{ ccp(sw/2 - ow, bh), ccp(sw - bw, bh), ccp(sw - bw, sh/2), ccp(sw, sh/2), ccp(sw, 0), ccp(sw/2 + ow, 0)}
	};
	
	CGPoint b1[1][8] = { // todo: ugly, cannot add slant to edges because it goes over the reflection line
		{ ccp(0, sh/2 + oh), ccp(bw, sh/2), ccp(bw, bh), ccp(sw - bw, bh), ccp(sw - bw, sh/2), ccp(sw, sh/2 + oh), ccp(sw, 0), ccp(0, 0) }
	};
	
	// create vertex vectors
	
	NSMutableArray* bottomButtonGroupVertices = [NSMutableArray array]; // todo: doesn't have to be mutable
	
	NSMutableArray* bottomButtonVertices1;
	NSMutableArray* bottomButtonVertices2;
	NSMutableArray* bottomButtonVertices3;
	NSMutableArray* bottomButtonVertices4;
	NSMutableArray* bottomButtonVertices5;
	
	switch (buttonCount) {
		case 1: // sequence might not work
			bottomButtonVertices1 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b1[0][0]],
									 [NSValue valueWithCGPoint:b1[0][1]],
									 [NSValue valueWithCGPoint:b1[0][2]],
									 [NSValue valueWithCGPoint:b1[0][3]],
									 [NSValue valueWithCGPoint:b1[0][4]],
									 [NSValue valueWithCGPoint:b1[0][5]],
									 [NSValue valueWithCGPoint:b1[0][6]],
									 [NSValue valueWithCGPoint:b1[0][7]],
									 nil];
			
			[bottomButtonGroupVertices addObject:bottomButtonVertices1];
			
			break;
			
		case 2:
			bottomButtonVertices1 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b2[0][0]],
									 [NSValue valueWithCGPoint:b2[0][1]],
									 [NSValue valueWithCGPoint:b2[0][2]],
									 [NSValue valueWithCGPoint:b2[0][3]],
									 [NSValue valueWithCGPoint:b2[0][4]],
									 [NSValue valueWithCGPoint:b2[0][5]],
									 nil];
			
			bottomButtonVertices2 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b2[1][0]],
									 [NSValue valueWithCGPoint:b2[1][1]],
									 [NSValue valueWithCGPoint:b2[1][2]],
									 [NSValue valueWithCGPoint:b2[1][3]],
									 [NSValue valueWithCGPoint:b2[1][4]],
									 [NSValue valueWithCGPoint:b2[1][5]],
									 nil];
			
			
			[bottomButtonGroupVertices addObject:bottomButtonVertices1];
			[bottomButtonGroupVertices addObject:bottomButtonVertices2];
			
			break;
			
		case 3:
			bottomButtonVertices1 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b3[0][0]],
									 [NSValue valueWithCGPoint:b3[0][1]],
									 [NSValue valueWithCGPoint:b3[0][2]],
									 [NSValue valueWithCGPoint:b3[0][3]],
									 [NSValue valueWithCGPoint:b3[0][4]],
									 [NSValue valueWithCGPoint:b3[0][5]],
									 nil];
			
			bottomButtonVertices2 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b3[1][0]],
									 [NSValue valueWithCGPoint:b3[1][1]],
									 [NSValue valueWithCGPoint:b3[1][2]],
									 [NSValue valueWithCGPoint:b3[1][3]],
									 nil];
			
			bottomButtonVertices3 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b3[2][0]],
									 [NSValue valueWithCGPoint:b3[2][1]],
									 [NSValue valueWithCGPoint:b3[2][2]],
									 [NSValue valueWithCGPoint:b3[2][3]],
									 [NSValue valueWithCGPoint:b3[2][4]],
									 [NSValue valueWithCGPoint:b3[2][5]],
									 nil];
			
			
			[bottomButtonGroupVertices addObject:bottomButtonVertices1];
			[bottomButtonGroupVertices addObject:bottomButtonVertices2];
			[bottomButtonGroupVertices addObject:bottomButtonVertices3];
			
			break;
			
		case 4:
			bottomButtonVertices1 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b4[0][0]],
									 [NSValue valueWithCGPoint:b4[0][1]],
									 [NSValue valueWithCGPoint:b4[0][2]],
									 [NSValue valueWithCGPoint:b4[0][3]],
									 [NSValue valueWithCGPoint:b4[0][4]],
									 [NSValue valueWithCGPoint:b4[0][5]],
									 nil];
			
			bottomButtonVertices2 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b4[1][0]],
									 [NSValue valueWithCGPoint:b4[1][1]],
									 [NSValue valueWithCGPoint:b4[1][2]],
									 [NSValue valueWithCGPoint:b4[1][3]],
									 nil];
			
			bottomButtonVertices3 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b4[2][0]],
									 [NSValue valueWithCGPoint:b4[2][1]],
									 [NSValue valueWithCGPoint:b4[2][2]],
									 [NSValue valueWithCGPoint:b4[2][3]],
									 nil];
			
			bottomButtonVertices4 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b4[3][0]],
									 [NSValue valueWithCGPoint:b4[3][1]],
									 [NSValue valueWithCGPoint:b4[3][2]],
									 [NSValue valueWithCGPoint:b4[3][3]],
									 [NSValue valueWithCGPoint:b4[3][4]],
									 [NSValue valueWithCGPoint:b4[3][5]],
									 nil];
			
			
			[bottomButtonGroupVertices addObject:bottomButtonVertices1];
			[bottomButtonGroupVertices addObject:bottomButtonVertices2];
			[bottomButtonGroupVertices addObject:bottomButtonVertices3];
			[bottomButtonGroupVertices addObject:bottomButtonVertices4];
			
			break;
			
		case 5:
			bottomButtonVertices1 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b5[0][0]],
									 [NSValue valueWithCGPoint:b5[0][1]],
									 [NSValue valueWithCGPoint:b5[0][2]],
									 [NSValue valueWithCGPoint:b5[0][3]],
									 nil];
			
			bottomButtonVertices2 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b5[1][0]],
									 [NSValue valueWithCGPoint:b5[1][1]],
									 [NSValue valueWithCGPoint:b5[1][2]],
									 [NSValue valueWithCGPoint:b5[1][3]],
									 nil];
			
			bottomButtonVertices3 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b5[2][0]],
									 [NSValue valueWithCGPoint:b5[2][1]],
									 [NSValue valueWithCGPoint:b5[2][2]],
									 [NSValue valueWithCGPoint:b5[2][3]],
									 nil];
			
			bottomButtonVertices4 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b5[3][0]],
									 [NSValue valueWithCGPoint:b5[3][1]],
									 [NSValue valueWithCGPoint:b5[3][2]],
									 [NSValue valueWithCGPoint:b5[3][3]],
									 nil];
			
			bottomButtonVertices5 = [NSMutableArray arrayWithObjects:
									 [NSValue valueWithCGPoint:b5[4][0]],
									 [NSValue valueWithCGPoint:b5[4][1]],
									 [NSValue valueWithCGPoint:b5[4][2]],
									 [NSValue valueWithCGPoint:b5[4][3]],
									 nil];
			
			
			[bottomButtonGroupVertices addObject:bottomButtonVertices1];
			[bottomButtonGroupVertices addObject:bottomButtonVertices2];
			[bottomButtonGroupVertices addObject:bottomButtonVertices3];
			[bottomButtonGroupVertices addObject:bottomButtonVertices4];
			[bottomButtonGroupVertices addObject:bottomButtonVertices5];
			
			break;
			
		default:
			CCLOGERROR(@"Whoa man. That's too many buttons. Are you a boy scout or somethin'?");
	}
	
	return bottomButtonGroupVertices;
}

// reflect point over a horizontal line
- (CGPoint)reflectPointOverHorizontal:(CGPoint)p y:(CGFloat)y {
	return ccp(p.x, p.y + (y - p.y) * 2);
}

- (void)reflectPoints:(NSMutableArray*)a {
	for (int i = 0; i < a.count; i++) {
		//CGPoint p = [[a objectAtIndex:i] CGPointValue];
		//CGPoint reflectedPoint = [self reflectPoint:p y:[CCDirector sharedDirector].winSize.height];
		//[a replaceObjectAtIndex:i withObject:[NSValue valueWithCGPoint:reflectedPoint]];
		
		[a replaceObjectAtIndex:i withObject:[NSValue valueWithCGPoint:[self reflectPointOverHorizontal:[[a objectAtIndex:i] CGPointValue] y:[CCDirector sharedDirector].winSize.height / 2]]]; // here's an example of where Obj-C syntax fails
	}
}

- (vector<ccColor3B>)createColorsWithButtonCount:(int)buttonCount colorPalette:(ccColor3B*)colorPalette  { // not needed, could have chosen color from array
	vector<ccColor3B> colors; // C++ vectors > NSMutableArray
	
	switch (buttonCount) {
		case 1:
			colors.push_back(colorPalette[2]); // todo: colors on 1v1 should be the opposite
			break;
			
		case 2:
			colors.push_back(colorPalette[1]);
			colors.push_back(colorPalette[3]);
			break;
			
		case 3:
			colors.push_back(colorPalette[1]);
			colors.push_back(colorPalette[2]);
			colors.push_back(colorPalette[3]);
			break;
			
		case 4:
			colors.push_back(colorPalette[0]);
			colors.push_back(colorPalette[1]);
			colors.push_back(colorPalette[3]);
			colors.push_back(colorPalette[4]);
			break;
			
		case 5:
			colors.push_back(colorPalette[0]);
			colors.push_back(colorPalette[1]);
			colors.push_back(colorPalette[2]);
			colors.push_back(colorPalette[3]);
			colors.push_back(colorPalette[4]);
			break;
			
		default:
			CCLOGERROR(@"You must construct additional pylons!");
			break;
	}
	
	return colors;
}

- (void)setColorPaletteWithDeviceSequencePosition:(int)deviceSequencePosition colorPalette:(ccColor3B*)colorPalette {
	
	int arrayIndex = deviceSequencePosition + 1;
	arrayIndex %= 3;
	
	CCLOG(@"TEST %i, %i", deviceSequencePosition, arrayIndex);
	
	ccColor3B colorPalettes[3][5] = {
		{ ccc3(255,0,100), ccc3(255,0,165), ccc3(255,0,228), ccc3(218,0,255), ccc3(154,0,255) }, // red to magenta
		// magenta to blue
		{ ccc3(0,100,255), ccc3(0,165,255), ccc3(0,228,255), ccc3(0,255,218), ccc3(0,255,154) }, // blue to cyan
		// cyan to green
		{ ccc3(0,255,100), ccc3(0,255,164), ccc3(0,255,228), ccc3(0,218,255), ccc3(0,154,255) }  // green to yellow
		// yellow to red
		
		// todo: add more colors palettes later
	};
	
	// set array by copying array
	for (int i = 0; i < 5; i++) {
		colorPalette[i] = colorPalettes[arrayIndex][i];
    }
}

@end
