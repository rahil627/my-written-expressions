/*
 
 File: ContactDataProvider.h
 Abstract: Implementation of the DataProvider specifically for beaming contacts.
 Version: 1.0
 
 */

#import "DataProvider.h"

@class GameManager;

// handles data sending and receiving
// to use it, check if dataReceived == kEmpty, if not compare to DataType
@interface PinkiesUpDataProvider : NSObject<DataProvider> {
	id delegateToCall;
	SEL selectorToCall;
	
	//NSString* dataLabel;
	
	//int dataToSend;
	NSData* serializedData;
	//int dataReceived;
	
	GameManager* gameManager;
}

//@property (nonatomic, readwrite, assign) int dataToSend;
//@property (nonatomic, readwrite, assign) int dataReceived;

- (id)initWithGameManager:(GameManager*)g;

@end
