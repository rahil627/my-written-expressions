//
//  RootViewController.h
//  PinkiesUp
//
//  Created by Jon Stokes on 4/26/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
