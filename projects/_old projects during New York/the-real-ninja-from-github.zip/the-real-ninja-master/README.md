The-Real-Ninja
==============

An auto-runner and slicing hybrid game prototype.

I believe this was my second game prototype. My main goal here was just to make a complete game within a time limit (Experimental Gameplay Project). I really wanted to try making everything: art, sounds, etc., and get the processes of making them all down, and getting the workflow down.

after this, i promised myself not to ever make crap, even if it's just for the sake of learning: strive to make art that i desire to or don't; Never steer away from my artistic desires, even if i don't have any past technical experience to realize it.
