This is a C# delegate/event style library

Visit https://github.com/robertpenner/as3-signals/wiki/_pages for example usage

