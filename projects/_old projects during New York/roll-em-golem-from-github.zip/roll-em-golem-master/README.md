# roll-em-golem
http://archive-server.globalgamejam.org/2012/rollem-golem

# from the ggj site:
Short Introduction:  Roll'em Golem is a challenging puzzle game. You must collect three pieces of a medallion in order to complete a stage. You will
Platform/System:  Web standard (Html5, Java, JavaScript, Flash)
Platform note:  Flash Player 11.1 or higher
Brief Play Description: 
Roll'em Golem

To play, go to the bin-release folder and pen Game.html in your web browser.

This game requires Flash 11.1 or higher to play.

Controls:

D - Move right
W - Jump
Space - Dash

If you step on a green (vine) block, it will not grow. If you jump on,
jump up into, fall onto, or dash into a a yelllow-ish block, you can move it.

These changes won't take effect until you finish the current stage iteration.

You play in the bottom of the screen, and see the future reflected in the top.

Collect the three red medallion parts to progress to the next level. Good luck!

-Team Two-Slice
Stefan Woskowiak
David Turchin
Michael Bartnett
Kendall Noble
Burak Karakas
Rahil Patel

NYC
