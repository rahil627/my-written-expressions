Poorly-Designed-Upgrades
========================

a game prototype with two ideas: the player’s drawings affect gameplay and too many upgrades can lead to negative results

this project also serves as a good example to come back to, to refresh my mind

since this was only my third game prototype, and my second time using the FlashPunk, and had a time limit (Experimental Gameplay Project), i chose to implement this idea on top of the shoot 'em up genre, as a sort of proof-of-concept.

the main idea / experiment driving this was to allow drawing input to affect gameplay. At the time I really liked the idea of iPads as a game platform, so drawing was on my mind. Also, I just don't think many games made good use of drawing input, where it actually affect gameplay (so, not using gestures to cast spells).

for this prototype to rock, i shouldn't have seperated the drawing screen from the playing screen. The player should have been able to draw in-game, having to draw the correct configuration of weapon upgrades on-the-fly as needed to defeat enemies... the code is there, just needs a little re-ordering.
