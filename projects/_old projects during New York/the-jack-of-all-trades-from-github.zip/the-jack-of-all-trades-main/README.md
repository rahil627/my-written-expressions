---
author: rahil627
comments: true
date: 2011-09-29 06:36:00+00:00
layout: post
link: https://mind.rathewolf.com/the-jack-of-all-trades/
slug: the-jack-of-all-trades
title: The Jack of all Trades
wordpress_id: 173
categories:
- Game Development
- Games
tags:
- actionscript
- actionscript video game
- capitalism
- experimental gameplay
- experimental gameplay project
- finding yourself
- flash
- flash video game
- independent game development
- independent video game
---

# the-jack-of-all-trades
a game prototype about choosing your own path in life
 
from 2011  
my first attempt to make a game  
made without a game framework!!  
 
# *copied from web-site post*
[Play the game](https://mind.rathewolf.com/the_jack_of_all_trades.html).

This game is my submission for the Experimental Gameplay Project. The theme is [story game.](http://experimentalgameplay.com/blog/2011/09/story-game-in-september-2011/)

It is the first game I've ever created. It took most of the 7 unemployed days to complete. I did not use a game engine, hence the prevalence of bugs. I learned and used ActionScript. Special thanks to the developers of [FlashDevelop](http://www.flashdevelop.org/wikidocs/index.php?title=Main_Page). Without it, I would have given up.

The game involves thoughts and experiences I've gone through recently. Mostly about finding yourself in a capitalist world. Although looking at the end product, the story seems like an overdone trope, something that belongs to the cheap clones theme. Still, I hope it resonates something within the player.

Hint: Look for your heart, not the golden trophy. (although I shouldn't have to give a hint, I feel my level design is bad)

EDIT: ...And the [results](http://experimentalgameplay.com/blog/2011/09/story-game-roundup/) are in!
