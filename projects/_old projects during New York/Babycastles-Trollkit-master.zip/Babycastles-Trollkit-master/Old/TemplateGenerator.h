#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class TemplateGenerator
{
private:
  string templateFilename;
  string gameName;
  string executablePath;
public:
};
