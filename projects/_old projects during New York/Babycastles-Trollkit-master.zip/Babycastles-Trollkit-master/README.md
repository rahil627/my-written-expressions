#WHAT?
The legendary Trollkit is a project initiated by [Babycastles](http://babycastles.com/) to facilitate the process of transforming a PC into an independent video game arcade machine.

#BUT WHY!?
Babycastles wants to place indepedent video game arcade cabinets into several venues in New York City.

#THAT'S IT?
No, wait, there's more! Currently, unless an independent game is sponsored or has very high production quality, it's unlikely to make the cut for Steam. Users have to venture to the author's website to download the game. Trollkit could be a hub for all indepedent games! =O

#HOW CAN I HALP?
Contact the person who committed code most recently and you too can help prevent terrible video games brainwashing the population.

#WHY AM I STILL READING AND NOT HALPING!?!?
