﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//this file contains multiple small project specific classes
namespace Trollkit {

}
