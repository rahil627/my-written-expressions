# verbal-assassin
can you imagine yourself as a verbal assassin..?
