# crosscalc
CrossCalc is a cross-platform expression calculator, similar to Microsoft's Power Calculator.

i found this bullshit on my sourceforge account! wowwww
