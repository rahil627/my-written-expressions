lollll, i found this bulllshit on my sourceforge account!

# splyce
Splyce is a side by side HTML editor so that you can see what the page looks like as you edit the code. Since Splyce is built with Qt, Splyce will run on Linux, Mac OS X, and Windows.
